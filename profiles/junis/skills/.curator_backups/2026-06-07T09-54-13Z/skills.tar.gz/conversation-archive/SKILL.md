---
name: conversation-archive
description: "对话归档管线：有价值对话产出的洞察自动回收进 Obsidian 知识库。用户说「归档」/「收」/「存」触发，AI 自动提炼关键内容→判定归属模块→写入 01-信息流→更新关联笔记的反链。"
version: 1.0.0
author: Junis
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [knowledge-base, obsidian, pipeline, conversation]
    category: note-taking
    related_skills: [obsidian, wechat-knowledge-ingestion, knowledge-synthesis]
---

# 对话归档管线（Conversation Archive）

> 每次跟 AI 深度对话产出的洞察，不应该散落在会话流里。
> 这个管线让有价值对话自动回收为知识库的永久资产。

---

## 触发词

用户在对话中说以下词语时触发：

| 词 | 场景 |
|----|------|
| "归档" | 通用 |
| "收" | 简短存档 |
| "存" | 同上 |
| "沉淀" | 深度归档（连带关联分析） |
| "这个可以写入 [[X]]" | 指定目标笔记 |

AI 也可以主动提议归档，格式：*「这个洞察值得归档 → [[预判模块]]，确认？」*

---

## 工作流

### 输入
当前对话中产生了有价值的内容，满足以下任一条件：
- 跨模块分析（≥2 个模块关联）
- 可沉淀的方法论框架
- 与现有知识库笔记形成新增关联
- 可复用到其他场景的洞察

### 处理步骤

```
用户说"归档" / AI提议 → 用户确认
  ↓
Step 1: 提炼关键洞察（从当前对话中提取3-5个核心点）
  ├── 每个洞察一句话概括 + 展开说明
  ├── 标注哪个模块最相关
  └── 标注与现有笔记的关联
  ↓
Step 2: 检查现有笔记
  ├── 用 search_files 确认已有相关笔记
  ├── 避免重复创建
  └── 找出可新增的反链
  ↓
Step 3: 写入 01-信息流/
  ├── 文件名: YYYY-MM-DD-对话-主题.md
  ├── frontmatter 含 status: conversation + related 字段
  └── 正文结构化（核心洞察→关联→可沉淀洞察）
  ↓
Step 4: 更新关联笔记反链
  ├── 在关联的永久笔记末尾添加「延伸讨论」引用
  └── 更新 01-信息流/index.md
  ↓
Step 5: 报告
  ├── 文件位置
  ├── 关联了哪些现有笔记
  └── 建议下一步
```

### 输出文件

保存到：`{VAULT_PATH}/01-信息流/YYYY-MM-DD-对话-主题.md`

### 笔记模板

```markdown
---
title: "对话：{主题名}"
tags:
  - 信息流
  - conversation
created: {YYYY-MM-DD}
source: hermes-conversation
status: conversation  # raw | conversation | processed
module: {归属模块}
related:
  - [[{已有笔记}]]
---

# 对话：{主题名}

> {一句话摘要}

## 核心洞察

### 1. {洞察1标题}
{洞察1内容}

### 2. {洞察2标题}
{洞察2内容}

### 3. {洞察3标题}
{洞察3内容}

## 与知识库的关联

| 关联笔记 | 关联说明 |
|---------|---------|
| [[笔记A]] | {说明} |

## 可沉淀的洞察

> 喂料管线处理时提取：
- **模块** → {信息}
- **新增关联** → [[笔记]]
- **桥接触发** → 是否需要

## 原始对话参考
```

---

## 与现有管线的关系

```
对话归档 (conversation-archive skill)
  ↓
01-信息流/ (status: conversation)
  ↓
喂料管线 (obsidian-ingestion-pipeline)
  ├── 下次 lint 扫描 status: conversation
  ├── 判断哪些可以提炼为永久笔记
  ├── 创建 ZN 笔记到对应模块
  └── 更新 status: processed
  ↓
知识库生长
```

---

## 原则

1. **不是每次对话都归档**。只归档有深度产出、跨模块价值、可回收的内容。
2. **归档 ≠ 终点**。它跟微信文章、读书笔记一样，先进入信息流，等待进一步加工。
3. **提前标注关联**。对话归档可以提前写好 related 字段，让喂料管线省掉猜归属的步骤。
4. **双向链接必须加**。归档时同时更新关联笔记的反链，防止信息孤岛。
5. **简单汇报**。归档完成后一句话报告位置和关联，不刷屏。

---

## Pitfalls

- **归档不等于替代思考**。归档是保存，不是理解。对话洞察归档后还需要喂料管线提炼为永久笔记。
- **不要过度归档**。日常问答、确认流程、单一事实查询不需要归档。
- **关联别太泛**。找到最相关的 2-3 个笔记即可，不需要关联所有模块。
- **Conversation 标签不和 raw 混用**。`status: conversation` 和 `status: raw` 是两个不同的入口标签，喂料管线需要区分处理。

---

## 实测案例

`references/first-test-2026-06-05.md` — 首次归档的完整记录（Robbin方案分析对话）。包含触发过程、所用步骤、归档产出、教训总结。
