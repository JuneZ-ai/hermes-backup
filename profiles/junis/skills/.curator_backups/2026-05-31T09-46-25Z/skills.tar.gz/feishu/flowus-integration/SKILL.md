---
name: flowus-integration
version: 1.2.1
description: "FlowUs（息流）集成本体——API探测、端点参考、五层工具架构定位、与Hermes/飞书/Obsidian/WB的集成管线。当用户提到息流/FlowUs、需要对外发布知识库、构建OPC内容管线、或讨论五层工具分工时加载本skill。"
metadata:
  requires:
    env: []
  related:
    skills: [lark-base, lark-doc, obsidian-ingestion-pipeline]
---

# FlowUs（息流）集成

## 1. 什么时候用本 skill

- 用户提到「息流」「FlowUs」「发布层」「对外展示」「公开知识库」
- 需要在五层工具架构中给息流定位
- 需要 Hermes 与息流 API 对接（CRUD 页面/数据库/块内容）
- 需要设计 OPC 内容管线（Obsidian → 息流 → 公众号）
- 需要把飞书 Bitable 数据同步到息流公开站点

## 2. 免费版限制

**FlowUs 免费版工作空间不支持 OAuth 接入。** 用户尝试授权外部应用时会提示「当前不支持免费版空间」。

| 版本 | API 支持 |
|------|---------|
| 免费版 | ❌ 无法创建外部应用、无法 OAuth 授权 |
| 专业版/团队版/企业版 | ✅ |

**替代方案（不付费的公开发布）：**

| 方案 | 成本 | 说明 |
|------|------|------|
| **飞书单篇文档公开**（实测可行） | ✅ 已有 | 创建 docx → 调用 `PATCH /open-apis/drive/v2/permissions/{token}/public` 设 `anyone_readable`。无需企业认证，单篇可公开分享。详见本 skill 的 `references/feishu-doc-public-sharing.md`。 |
| **飞书 Wiki 知识库公开** | ❌ 需企业注册 | 设为公开后 Hermes 可通过 API 创建并发布页面。详见 `lark-wiki` skill。 |
| Notion | 免费（需翻墙） | 免费版有 API，可做公开站点 |
| GitHub Pages | 免费 | 适合技术内容 |

## 3. 五层工具架构

用户当前的工具体系采用**五层分工互不重叠**的架构：

```
┌─────────────────────────────────────────────────┐
│  Hermes Agent      AI编排层（大脑/调度/黏合）       │
├──────────┬──────────────────┬────────────────────┤
│  飞书     │   Obsidian       │  息流 (FlowUs)     │
│  协作层   │  知识层          │  发布层             │
│  IM/Bitable│  第二大脑/深度笔记 │  对外展示/公开站点   │
│  云文档/日历 │  双向链接图谱    │  内容日历/OPC管线    │
├──────────┴──────────────────┴────────────────────┤
│  WB (WorkBuddy)  Windows物理层（本地自动化）         │
└─────────────────────────────────────────────────┘
```

### 每层定位

| 工具 | 定位 | 对内/对外 | 一句话 |
|------|------|----------|--------|
| **Hermes** | 大脑 | — | 调度燕青，不存内容但驱动一切 |
| **飞书** | 办公室 | 🔒 对内 | 团队聊事、Bitable 存结构化数据 |
| **Obsidian** | 大脑仓库 | 🔒 私有 | 第二大脑，深度知识吸收 |
| **息流** | 展示橱窗 | 🔓 半公开 | 能给别人看的东西放这里 |
| **WB** | 车间机器 | 🖥️ 本地 | 只有这台 Windows 能干的活 |

## 3. FlowUs API 概览

> API 文档在 `https://flowus.cn/openapi`（需登录后访问）。**认证走 OAuth2 应用模式**（类似飞书自建应用），不是简单的静态 Token。

### 3.1 基本信息

| 项目 | 值 |
|------|-----|
| **Base URL** | `https://flowus.cn/api/v1/` |
| **认证模型** | **OAuth2 应用模式**（App ID + App Secret → access token） |
| **文档入口** | `flowus.cn/openapi`（SPA，需浏览器登录） |
| **应用版本** | v1.146.0+ |
| **测试状态** | 全部端点已探测存在（返回 401 表示需认证，非 404） |

### 3.2 认证流程

FlowUs 不走简单的 Bearer Token，而是**创建外部应用**获取凭证：

```
开发者中心 (settings/developer)
  → 创建外部应用 (create app)
  → 获得 App ID / Client ID + App Secret / Client Secret
  → OAuth2 获取 access token
  → 用 Bearer <access_token> 调 API
```

#### 首次对接步骤

1. 用户登录 FlowUs Web → 头像 → 设置 → 开发者中心 (`/settings/developer`)
2. 点击「创建外部应用」，填写：
   - **应用名称**：如 `Hermes Agent`
   - **网站 URL**：`https://hermes-agent.nousresearch.com`（必填，推荐填 Hermes 官网或用户 GitHub）
   - **重定向 URL**：`http://localhost:7897/callback`（OAuth 回调，Hermes 在 WSL 环境无网页服务器接收，填占位地址）
3. 选择权限范围（Scope）：
   - ✅ **读取内容** — Hermes 读取息流页面和数据
   - ✅ **插入内容** — Hermes 在息流创建页面
   - ✅ **更新内容** — Hermes 编辑已有页面
   - ⬜ **读取用户邮箱** — 一般不需要
   - ⬜ **读取用户信息** — 一般不需要
4. 创建后拿到 **App ID**（UUID 格式，如 `0ef0c0db-...`）和 **App Secret**（只显示一次）
5. 发给 Hermes，完成 OAuth2 鉴权和 API 实测

#### OAuth2 端点

| 端点 | 方法 | 说明 |
|------|------|------|
| `https://api.flowus.cn/oauth/authorize` | GET | 用户授权页，参数: `client_id`, `response_type=code`, `redirect_uri`, `scope`, `state` |
| `https://flowus.cn/api/oauth/token` | POST | 换 access_token，支持 `authorization_code` 和 `refresh_token`（**不支持** `client_credentials`） |

**授权 URL 格式**：
```
https://api.flowus.cn/oauth/authorize?client_id={APP_ID}&response_type=code&redirect_uri={REDIRECT_URI}&scope=all&state={STATE}
```

**Token 端点返回**（测试 `client_credentials` 时）：
```json
{"error":"unsupported_grant_type","error_description":"Only authorization_code and refresh_token are supported"}
```

#### 已知限制

| 限制 | 说明 |
|------|------|
| **免费版被拒** | 用户打开授权 URL 后提示「当前不支持免费版空间」，免费版无法完成 OAuth 授权 |
| **需浏览器授权** | 用户必须手动在浏览器打开授权 URL 并登录息流，Hermes 无法自助获取 token |
| **无 CLI 工具** | 和飞书 lark-cli 不同，FlowUs 没有官方 CLI 工具，Hermes 需用 curl 或 Python requests 直调 |

> ⚠️ 由于免费版不开放 API，**息流集成目前不可行**。替代方案见「免费版限制」章节。

### 3.3 核心能力矩阵

| 类别 | 端点模式 | 能力 | Hermes 集成用途 |
|------|---------|------|----------------|
| **页面** | `/page/{id}` | 创建/读取/更新/导出页面 | 写公众号文章到内容日历 |
| **数据库** | `/workspace/{id}/pages` | 查询行记录（带筛选/排序） | 读取选题看板、状态排期 |
| **块** | `/page/{id}/block` | CRUD 块内容（文本/图片/表格等） | 精细化排版、内容同步 |
| **文件** | `/upload` | 上传附件 | 插图、附件上传 |
| **Webhooks** | （白名单申请） | 事件通知 | 页面变更时触发 Hermes 任务 |
| **workspace** | `/workspace/{id}` | 工作空间信息 | 枚举空间结构 |

### 3.4 块类型支持

| 块类型 | 状态 | 说明 |
|--------|------|------|
| 文本/标题/列表 | ✅ | 基础排版 |
| 图片/文件 | ✅ | 附件上传 |
| 代码块 | ✅ | 技术内容 |
| 表格/引用/分隔线 | ✅ | 标准排版 |
| 嵌入/链接预览 | ✅ | 外部链接展示 |

## 4. 三条集成管线

### 管线 A：Hermes 直调（最直接）

```
Hermes → curl/requests → FlowUs REST API
```

适合：创建公开页面、更新内容日历、同步结构化数据。

```bash
# 示例：创建息流页面
curl -s -X POST https://flowus.cn/api/v1/page \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "每日寓言 - 2026-05-30",
    "content": [
      {"type": "heading", "attrs": {"level": 2}, "content": [{"text": "标题"}]},
      {"type": "paragraph", "content": [{"text": "正文..."}]}
    ]
  }'
```

### 管线 B：OPC 内容管线（推荐首发试点）

```
Obsidian 深度笔记 → Hermes 提炼文章 → 息流内容日历 Database → 公众号发布
```

1. Hermes 从 Obsidian 读笔记
2. AI 提炼成 800 字公众号文章
3. 写入息流「内容日历」Database（状态: 待审）
4. 息流提供对外预览链接
5. 用户确认后手动发布到公众号

### 管线 C：飞书 ↔ 息流桥接

```
飞书 Bitable（三表：搭建日志/每日记录/收藏随想录）
  → Hermes 定时同步
  → 息流公开站点（对外知识库）
```

飞书保持对内权威数据源，息流作为公开镜像。

## 5. API 探测配方

当需要探测一个 SPA 应用（如 FlowUs）的 REST API 时：

```bash
# 1. 检查已知端点是否存在
curl -sL -o /dev/null -w "%{http_code}" "https://flowus.cn/api/v1/page"

# 2. 401 = 需认证但端点存在（好信号）
# 3. 404 = 端点不存在
# 4. 200/HTML = SPA 通吃路由

# 5. 检查常见 API 路径模式
for path in page workspace block upload share thread; do
  curl -sL -o /dev/null -w "%{http_code}" "https://flowus.cn/api/v1/$path"
done

# 6. 检查 API 版本号
for v in v1 v2 v3; do
  curl -sL -o /dev/null -w "%{http_code}" "https://flowus.cn/api/$v/page"
done
```

## 6. 注意事项

| 风险 | 说明 |
|------|------|
| **文档需登录** | API 文档在 SPA 后台，curl 无法抓取。首次集成需要用户创建外部应用后提供 App ID + App Secret |
| **OAuth2 流程** | 不是简单的 Bearer Token，需先完成 OAuth2 握手拿到 access_token（可能有时效） |
| **无 CLI 工具** | 不像飞书有 lark-cli，FlowUs 需要 Hermes 用 curl 或 Python requests 直调 |
| **Webhooks 申请制** | 事件推送可能需白名单，否则只能拉模式 |
| **Rate Limit 未公开** | 写入 ≤10/min 为安全阈值 |
| **SPA 通吃路由陷阱** | `/openapi/openapi.json`、`/swagger.json` 等看似 API 文档的 URL 实际返回 SPA HTML |

## 7. 参考文件

- [`references/flowus-api-endpoints.md`](references/flowus-api-endpoints.md) — API 端点探测详细记录
- [`references/feishu-doc-public-sharing.md`](references/feishu-doc-public-sharing.md) — 飞书文档公开分享（permission-public/patch API 实测配方）
- [`references/lark-wiki-public-publish.md`](references/lark-wiki-public-publish.md) — 飞书 Wiki 公开发布层参考（替代方案）
