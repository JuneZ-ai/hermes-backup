# 飞书文档公开分享（permission-public/patch）

通过 `PATCH /open-apis/drive/v2/permissions/:token/public` 将飞书文档设为互联网公开访问。

## 适用场景

- 飞书 Wiki 知识库公开需企业注册，个人/团队版不支持
- **单篇飞书文档**可通过 API 直接设为公开链接，无需企业认证（实测可行）
- 推荐：发布类内容走独立 docx（非 Wiki 节点），可自由设公开

## 完整调用

```bash
lark-cli api PATCH /open-apis/drive/v2/permissions/<doc_token>/public \
  --as user \
  --params '{"type":"docx"}' \
  --data '{
    "external_access_entity": "open",
    "link_share_entity": "anyone_readable",
    "security_entity": "anyone_can_view"
  }'
```

## 参数说明

| 参数 | 值 | 效果 |
|------|----|------|
| `external_access_entity` | `"open"` | 允许分享到组织外 |
| `link_share_entity` | `"anyone_readable"` | 互联网上任何人可阅读 |
| `security_entity` | `"anyone_can_view"` | 可阅读者可复制/打印/下载 |
| `comment_entity` | `"anyone_can_view"`（可选） | 可阅读者可评论 |

## 完整工作流

```bash
# 1. 创建文档（Markdown 格式）
lark-cli docs +create --api-version v2 \
  --doc-format markdown \
  --content @./article.md \
  --title "文章标题" \
  --as user

# 返回结果中取 document_id 作为 doc_token

# 2. 设公开
lark-cli api PATCH /open-apis/drive/v2/permissions/<doc_token>/public \
  --as user \
  --params '{"type":"docx"}' \
  --data '{"external_access_entity":"open","link_share_entity":"anyone_readable","security_entity":"anyone_can_view"}'

# 3. 返回公开链接
echo "https://my.feishu.cn/docx/$DOC_TOKEN"
```

## 验证

```bash
lark-cli api GET /open-apis/drive/v2/permissions/<doc_token>/public \
  --as user --params '{"type":"docx"}' | jq '.data.permission_public'
```

## 约束

| 约束 | 说明 |
|------|------|
| `token` 必须是文档 obj_token | 不是 Wiki 节点 token；Wiki 内文档受空间权限约束 |
| `--as user` 必须 | bot 身份返回 1063002 Permission denied |
| 响应 `1066001 Internal Error` | 通常是文档在私有 Wiki 空间内，换独立 docx 即可 |
| 企业安全策略 | `external_access_entity: "open"` 可被企业全局策略覆盖 |

## API 参考

- **方法**: `PATCH`
- **路径**: `/open-apis/drive/v2/permissions/{token}/public`
- **权限**: `wiki:wiki` / `docs:doc` / `drive:drive` 等（任一即可）
- **频率限制**: 100 次/分钟
- **文档来源**: 飞书开放平台「更新云文档权限设置」
