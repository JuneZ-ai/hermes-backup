# FlowUs（息流）API 端点探测记录

> 探测日期：2026-05-30
> 探测工具：curl (CLI in Hermes WSL)
> 认证状态：Unauthenticated（所有端点返回 401，确认端点存在且需认证）
>
> **重要发现：认证走 OAuth2 应用模式，不是简单 Bearer Token。**
> **免费版不支持 API**：用户打开授权 URL 后提示「当前不支持免费版空间」。

## API 基础地址

```
Base URL: https://flowus.cn/api/v1/
文档入口: https://flowus.cn/openapi（SPA 应用，需浏览器登录）
           https://help.flowus.cn（同 SPA）
           https://docs.flowus.cn（同 SPA）
开发者:   https://open.flowus.cn（同 SPA）
认证:     Authorization: Bearer <access_token>
```

## 端点探测结果

### REST API 端点（均返回 401，确认存在）

```
API Base:
  https://flowus.cn/api/v1/               → 401
  https://flowus.cn/api/v1/page           → 401
  https://flowus.cn/api/v1/workspace      → 401
  https://flowus.cn/api/v1/block          → 401
  https://flowus.cn/api/v1/share          → 401
  https://flowus.cn/api/v1/thread         → 401
  https://flowus.cn/api/v1/upload         → 401
  https://flowus.cn/api/v1/search         → 401

V2 端点（存在但版本号未知）:
  https://flowus.cn/api/v2/pages          → 401
  https://flowus.cn/api/export            → 401
  https://flowus.cn/api/info              → 401

Swagger/OpenAPI Spec (SPA 通吃路由，返回 HTML):
  https://flowus.cn/openapi/openapi.json  → 200 (HTML)
  https://flowus.cn/openapi/v1/swagger.json → 200 (HTML)
  https://flowus.cn/openapi/v3/api-docs   → 200 (HTML)
  https://flowus.cn/.well-known/openapi.json → 200 (HTML)
```

### OAuth2 认证端点

| 端点 | 方法 | 状态 | 说明 |
|------|------|------|------|
| `https://flowus.cn/oauth/token` | POST | 405 | 端点存在，可能不在根路径 |
| `https://flowus.cn/oauth/authorize` | POST | 405 | 同上 |
| `https://flowus.cn/api/oauth/token` | POST | 400 | **Token 交换端点**，返回明确错误说明 |
| `https://api.flowus.cn/oauth/authorize` | — | — | 用户浏览器授权页 |

**Token 端点返回**（client_credentials 测试）：
```json
{"error":"unsupported_grant_type","error_description":"Only authorization_code and refresh_token are supported"}
```

结论：仅支持 `authorization_code` 和 `refresh_token`，不支持 `client_credentials`。

### 帮助/文档页面（均为 SPA）

| URL | HTTP 状态 | 说明 |
|-----|-----------|------|
| `https://help.flowus.cn` | 200 | SPA 同 app |
| `https://help.flowus.cn/api` | 200 | SPA |
| `https://help.flowus.cn/openapi` | 200 | SPA |
| `https://help.flowus.cn/api-reference` | 200 | SPA |
| `https://help.flowus.cn/developer` | 200 | SPA |
| `https://docs.flowus.cn` | 200 | SPA 同 app |
| `https://developer.flowus.com` | NXDOMAIN | 不存在 |
| `https://dev.flowus.cn` | NXDOMAIN | 不存在 |

### 非 API 页面

| URL | 状态 | 说明 |
|-----|------|------|
| `https://flowus.cn/runtime-config.json` | 200 | 运行时配置 |
| `https://flowus.cn/site.webmanifest` | 200 | 站点清单 |
| `https://flowus.cn/openapi` | 200 | SPA |
| `https://flowus.cn/docs/openapi` | 200 | SPA |
| `https://flowus.cn/feature/api` | 200 | SPA |
| `https://flowus.cn/help/api/zh-cn` | 401 | API 文档需认证 |
| `https://flowus.cn/swagger` | 404 | 不存在 |

## 应用创建

在 `settings/developer` 创建外部应用时需要填写：

| 字段 | 示例 | 说明 |
|------|------|------|
| 应用名称 | `Hermes Agent` | 必填 |
| 网站 URL | `https://hermes-agent.nousresearch.com` | 必填，OAuth 注册展示信息 |
| 重定向 URL | `http://localhost:7897/callback` | 必填，OAuth 回调地址，填占位地址即可 |
| 读取内容 | ✅ | 必选，Hermes 读取页面和数据 |
| 插入内容 | ✅ | 必选，Hermes 创建页面 |
| 更新内容 | ✅ | 必选，Hermes 编辑页面 |
| 读取用户邮箱 | ⬜ | 一般不需要 |
| 读取用户信息 | ⬜ | 一般不需要 |

## 应用版本

```
FlowUs Web App: 1.146.0-1779799208614
CDN: cdn2.flowus.cn
JS 框架: React + Tiptap (富文本编辑器) + Vite
```

## 前端 JS 中发现的内部 API 路由关键词

从 minified JS 中提取的相关字符串：

```
/api/v1/
/page
/workspace
/block
/share
/upload
/export
/thread
via_notion_api
oauth
client_id
developer_center
```

## 认证模型（已确认）

FlowUs 不走简单的 Bearer Token，而是 **OAuth2 应用模式**：

```
开发者中心 (settings/developer)
  → 创建外部应用 (create app)
  → 获得 App ID / Client ID + App Secret / Client Secret
  → OAuth2 握手获取 access_token（仅 authorization_code 模式）
  → 用 Bearer <access_token> 调 API
```

## 首次对接步骤

1. 用户登录 FlowUs Web → 头像 → 设置 → 开发者中心 (`settings/developer`)
2. 点击「创建外部应用」，填写名称/网站URL/重定向URL/选择权限
3. 创建成功后拿到 **App ID**（UUID）和 **App Secret**（只显示一次）
4. Hermes 构造授权 URL，用户浏览器打开并授权
5. 拿到 authorization_code → 换 access_token → 开始调 API

**⚠️ 免费版用户在第 4 步会收到「当前不支持免费版空间」的提示，无法完成授权。**
