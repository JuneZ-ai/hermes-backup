# 飞书文档公开分享 — 参考文档

> 当 FlowUs 不可用（免费版无 API）时，使用飞书文档作为公开发布层的方案。
> 分两种场景：**知识库公开**（需企业注册）和 **单篇文档公开**（无需企业注册，实测可行）。

## 场景一：单篇文档公开（推荐，无需企业注册）

创建独立的飞书 docx（不在知识库内），通过 Permission Public API 设为互联网公开。

### 完整流程

```bash
# 1. 创建文档（Markdown 格式）
lark-cli docs +create --api-version v2 \
  --doc-format markdown \
  --content @./article.md \
  --title "文章标题" \
  --as user

# → 返回 document_id 和 url

# 2. 设为公开访问
lark-cli api PATCH /open-apis/drive/v2/permissions/{document_id}/public \
  --as user \
  --params '{"type":"docx"}' \
  --data '{
    "external_access_entity": "open",
    "link_share_entity": "anyone_readable",
    "security_entity": "anyone_can_view"
  }'

# 验证: 返回 code=0 表示成功
```

### 关键参数

| 字段 | 值 | 效果 |
|------|----|------|
| `external_access_entity` | `"open"` | 允许分享到组织外 |
| `link_share_entity` | `"anyone_readable"` | 互联网上任何人可阅读 |
| `security_entity` | `"anyone_can_view"` | 可阅读用户可打印/下载/复制 |
| `comment_entity` | `"anyone_can_view"` | 可阅读用户可评论 |

### 所需权限

- `wiki:wiki`（查看、编辑和管理知识库）
- 或 `docs:doc`（查看、评论、编辑和管理文档）
- 或 `docs:permission.setting:write_only`（修改云文档权限设置）

### 注意事项

- 文档如果在**私有知识空间**中，调该 API 会报 `1066001 Internal Error`。解决：在飞书 UI 将知识空间设为公开，或单独给应用授权文档。
- bot 身份（`--as bot`）会报 `1063002 Permission denied`，需要先将应用添加为知识库管理员或文档协作者。
- 企业的全局安全设置可能覆盖单篇文档的公开权限。

## 场景二：知识库公开（需企业注册）

将整个飞书知识库（Wiki 空间）设为公开访问，适用于作品集/专栏。

### 当前限制

| 操作 | 方式 | 状态 |
|------|------|------|
| 创建知识空间 | API | ✅ 可行 |
| 创建知识节点 | API | ✅ 可行 |
| 写入文档内容 | API | ✅ 可行 |
| 设置空间为公开 | API | ❌ `visibility` 和 `open_sharing` 无修改端点 |
| 设置空间为公开 | 飞书 UI | ❌ 提示「需要注册企业」 |

### 已知陷阱

| 问题 | 现象 | 原因 | 解决 |
|------|------|------|------|
| 1066001 Internal Error | user 身份调权限 API 报错 | 父知识空间为 private，子节点无法设为公开 | 在飞书 UI 手动将空间改为公开 |
| 1063002 Permission denied | bot 身份调权限 API 报错 | 应用未获得文档协作者权限 | 在飞书 UI 将应用添加为空间管理员 |
| `@./file` 路径错误 | `--content @/absolute/path` 报错 | CLI 限制 `@file` 必须用相对路径 | cd 到文件所在目录或用 `./file` |

### 运维检查

```bash
# 查看空间状态
lark-cli wiki spaces get --params '{"space_id":"<id>"}'
# → visibility: "public" / "private"
# → open_sharing: "open" / "closed"

# 创建节点
lark-cli wiki +node-create --as user \
  --space-id "<space_id>" \
  --title "标题" \
  --obj-type docx

# 设节点文档为公开
# （如果空间已是 public/open_sharing）
```

## 推荐策略

1. **单篇文档公开**作为首选方案 — 无需企业注册，每篇文章独立控制
2. 知识库作为内部**内容组织空间**（管理选题/排期/状态），不对外公开
3. OPC 发布管线：Obsidian → Hermes → 飞书 docx（草稿+公开链接）→ 公众号
