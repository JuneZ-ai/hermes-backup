---
name: github-skill-tracker
description: "GitHub 技能仓库追踪与自动同步。监控指定 GitHub 仓库的更新，自动拉取最新版本到本地，并在发现重大升级时执行版本对比与升级流程。适用于维护花叔(alchaincyf)、Andy(AIPMAndy)等外部技能库。Use when user mentions '达尔文升级了', '技能更新了', 'github技能同步', 'skill升级了', '花叔更新了', 'nuwa-skill更新', 'darwin升级', '自动同步技能', 'track repos', 'sync skills'."
---

# GitHub Skill Tracker

> 监控指定 GitHub 技能仓库的更新，自动同步到本地，并在发现重大版本升级时执行完整升级流程（备份 → 对比 → 同步 → 验证）。

---

## 设计理念

技能库是知识工作的基础设施。外部技能（尤其是花叔、Andy 等高质量技能）持续迭代，本地版本若不及时更新，会：
- 错过关键修复（bug fix、边界条件补充）
- 无法使用新功能（新维度、新流程、新工具）
- 优化效果停留在旧版水平

本 skill 实现「**被动发现 → 主动同步 → 版本对比 → 一键升级**」的闭环。

---

## 使用场景

### 1. 监控仓库更新（cron 定期检查）

```bash
# 检查 tracked 仓库列表
ls ~/github-tracked/<owner>/<repo>/

# 查看最新 commit
cd ~/github-tracked/alchaincyf/darwin-skill
git log --oneline -5
git remote update
git status
```

**cron 集成**：每日/每12小时自动执行，检测到新 commit 时推送通知。

### 2. 发现升级后的完整流程

当用户说「XX 技能升级了」时，执行以下 Phase：

#### Phase 0: 确认升级范围

```bash
# 1. 查看本地当前版本
cd ~/.hermes/skills/<category>/<skill-name>/
head -20 SKILL.md  # 看版本标识

# 2. 查看 GitHub 最新版本
cd ~/github-tracked/<owner>/<repo>/
head -20 SKILL.md
git log --oneline -5
```

#### Phase 1: 版本对比

```bash
# 查看文件行数差异
wc -l ~/.hermes/skills/<...>/SKILL.md ~/github-tracked/<...>/SKILL.md

# 查看最近提交的变更摘要
cd ~/github-tracked/<owner>/<repo>/
git log --oneline --since="1 week ago"
git show HEAD --stat  # 最新提交改了哪些文件
```

**快速判断是否重大升级：**
- 文件行数增加 > 10%
- description/frontmatter 出现新关键词（如 `v2.0`、`2.0`、新论文引用）
- commit message 包含 `v2`、`major`、`breaking change`、`rewrite`

#### Phase 2: 执行升级

```bash
# 1. 备份当前版本（带时间戳）
cd ~/.hermes/skills/<category>/<skill-name>/
cp SKILL.md SKILL.md.bak.$(date +%Y%m%d-%H%M)

# 2. 复制 GitHub 最新版本
cp ~/github-tracked/<owner>/<repo>/SKILL.md .

# 3. 同步辅助文件（如有）
# 检查 GitHub 版本是否有新增的 references/ scripts/ templates/ assets/
cd ~/github-tracked/<owner>/<repo>/
find . -type f -name '*.md' -o -name '*.json' -o -name '*.html' | grep -v '.git' | while read f; do
  # 删除本地旧版本，复制新版本
  rm -f ~/.hermes/skills/<category>/<skill-name>/$f
  cp --parents $f ~/.hermes/skills/<category>/<skill-name>/
done

# 4. 验证升级结果
cd ~/.hermes/skills/<category>/<skill-name>/
grep -E "v[0-9]+\.[0-9]+|[0-9] 维|新增|upgrade" SKILL.md | head -5
```

#### Phase 3: 告知用户

```
✅ [skill-name] 已升级到 vX.Y

升级摘要：
- 版本：v1.0 → v2.0
- 文件行数：XXX → XXX
- 核心变更：
  1. [维度/功能/流程] 从 X → Y
  2. 新增 [具体内容]
  3. 修复 [具体问题]
- 辅助文件：新增/更新 [list]

本地备份：SKILL.md.bak.YYYYMMDD-HHMM
GitHub 提交：[commit hash]
```

---

## 追踪仓库清单

默认追踪以下仓库（可在配置中扩展）：

| 所有者 | 仓库 | 本地路径 | 说明 |
|--------|------|----------|------|
| alchaincyf | darwin-skill | ~/github-tracked/alchaincyf/darwin-skill | 技能优化器 |
| alchaincyf | nuwa-skill | ~/github-tracked/alchaincyf/nuwa-skill | 女娲造人 |
| alchaincyf | huashu-design | ~/github-tracked/alchaincyf/huashu-design | 花叔设计 |
| alchaincyf | huashu-skills | ~/github-tracked/alchaincyf/huashu-skills | 技能合集 |
| AIPMAndy | hermes-skills-andy | ~/github-tracked/AIPMAndy/hermes-skills-andy | Andy 技能 |
| AIPMAndy | soskill | ~/github-tracked/AIPMAndy/soskill | 结构化技能 |
| AIPMAndy | goskill | ~/github-tracked/AIPMAndy/goskill | 目标驱动执行 |
| AIPMAndy | DNASkill | ~/github-tracked/AIPMAndy/DNASkill | DNA记忆 |

---

## 异常处理

| 场景 | 处理方式 |
|------|----------|
| GitHub 仓库未 clone | `git clone https://github.com/<owner>/<repo>.git ~/github-tracked/<owner>/<repo>` |
| 本地版本非 git 仓库 | 跳过 git 操作，直接文件覆盖备份 |
| 升级后文件异常 | 从 `.bak.YYYYMMDD-HHMM` 恢复 |
| 辅助文件冲突 | 先删除本地版本，再复制新版本（避免版本混乱） |

---

## 关键原则

1. **先对比再升级**：不看差异就覆盖 = 盲升级
2. **必须备份**：每次升级前创建时间戳备份
3. **辅助文件一并同步**：references/ scripts/ templates/ 等文件与 SKILL.md 版本绑定
4. **记录升级摘要**：告知用户具体改了什么，不只是「已升级」

---

## 快速命令

```bash
# 一键检查所有 tracked 仓库状态
for d in ~/github-tracked/*/*/; do
  echo "=== $(basename $d) ==="
  cd "$d" && git status && echo
done

# 一键同步所有仓库（fetch only，不自动升级）
for d in ~/github-tracked/*/*/; do
  cd "$d" && git remote update && git status
done
```
