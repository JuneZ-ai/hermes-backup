# Self-Improving Agent v3.0.6 — Evaluation Notes

**Source**: `/mnt/d/龙虾技能/skill/self-improving-agent-3.0.6/`  
**Original author**: peterskoett (改版 for OpenClaw)  
**Original repo**: https://github.com/peterskoett/pskoett-ai-skills/tree/main/skills/self-improvement  
**Date evaluated**: 2026-05-28

## What It Does

A structured system for AI agents to log errors, corrections, and learnings to markdown files (`.learnings/LEARNINGS.md`, `ERRORS.md`, `FEATURE_REQUESTS.md`), with a promotion pipeline to permanent project files (CLAUDE.md, AGENTS.md, SOUL.md, TOOLS.md).

## What's Worth Keeping (vs Why We Didn't Install It)

| Feature | Verdict | Reason |
|:--------|:--------|:-------|
| Recurrence detection + promotion rule | ✅ **Adopted — core of `meta-learning` skill** | Essential pattern: ≥3 recurrences across ≥2 tasks in 30 days → promote |
| Structured ID system (LRN-YYYYMMDD-XXX) | ❌ Overhead | Hermes `memory` + `session_search` do this better without manual numbering |
| `.learnings/` directory files | ❌ Overhead | Hermes has native persistent memory, no need for flat files |
| Hook scripts (activator.sh, error-detector.sh) | ❌ OpenClaw-specific | Not portable to Hermes/Feishu environment |
| Skill extraction workflow | ❌ Already covered | Hermes `skill_manage` has a cleaner interface |

## Key Insight: Less Is More

The original skill is ~600 lines with hooks, ID generators, and complex promotion logic. The essential pattern fits in **one rule**:

> **Third repeat = promote.**

Everything else is machinery. The user's philosophy ("最减法，清楚冗余和重复，这也是一种进化") directly validates this judgment.
