---
name: meta-learning
description: "Agent self-improvement from recurring patterns — experience precipitation, three-strike promotion rule, and session-to-memory pipeline. Use when: evaluating a learning from a session, deciding whether a correction or pattern warrants promotion to memory/skill, reviewing recurring issues across sessions, or taking stock of meta-learning signals. Complements darwin-skill (which optimizes existing skills) — this skill governs what gets promoted into a skill or memory in the first place."
tags: [self-improvement, experience-precipitation, recurrence-detection, skill-promotion, meta-cognition]
related_skills: [darwin-skill, systematic-debugging, requesting-code-review, knowledge-architecture]
---

# Meta-Learning: Experience Precipitation

> **One-shot fix is noise. Third repeat is a pattern. Patterns get promoted.**

## Design Philosophy

The core insight from evaluating external self-improvement systems: most "learning" infrastructure (numbered ID schemes, `.learnings/` directories, hook scripts) is overhead. The essential pattern is simpler — **a lightweight detection loop with a promotion threshold.**

### Three-Strike Promotion Rule

| Strike | Condition | Action |
|:------|:----------|:-------|
| **1st** | A correction, error, or recurring issue occurs | Note it mentally. If significant (>2 min to resolve), save to memory immediately |
| **2nd** | Same pattern appears in a **different task/context** | Raise internal flag. Start watching for recurrence |
| **3rd** | Same pattern within **30 days**, across **≥2 distinct tasks** | **Promote** — embed in memory or create/update a skill |

The promotion action depends on the nature of the pattern:

| Pattern Type | Promote To | Example |
|:------------|:-----------|:--------|
| User preference / pet peeve | `memory` (user profile) | "User hates verbose preamble before answers" |
| Workflow correction | The relevant skill's SKILL.md | "Always convert Windows paths to /mnt/c/ before using tools" |
| Tool quirk / gotcha | `memory` (notes) | "lark-cli needs both drive:drive AND space:document scopes" |
| Reusable technique | Create a new skill | Full workflow for a recurring task class |

### Signals Beyond Explicit Corrections

Watch for these weaker signals too — they often precede a third strike:

| Signal | What It Means |
|:-------|:-------------|
| You catch yourself about to repeat a past mistake | The pattern is already internalized, but the skill/memory isn't updated |
| User says "you always do X" or "last time we..." | A pattern has already struck ≥2 times — promote immediately |
| Same tool produces same unexpected behavior | Environment or config issue that needs documenting |
| A question the user asks repeatedly | Could indicate a blind spot worth noting as a knowledge gap |

### Session Scan at Natural Breakpoints

At the end of major sessions or before new tasks:

```
1. Scan memory for recent entries from the last 30 days
2. Check for recurrence: same topic appearing with ≥2 entries?
3. If yes → check threshold: ≥3 occurrences across ≥2 tasks?
4. If threshold met → promote (merge into user profile or skill)
5. Clean up transient memory entries that are now consolidated
```

---

## Supported File Types

This skill produces two kinds of outputs:

| Type | Where | Persistence |
|:-----|:------|:------------|
| **Memory entries** | `memory` tool (user or notes) | Survives across sessions |
| **Skill updates** | `skill_manage(action='patch')` | Durably changes how a task class is handled |
| **New skills** | `skill_manage(action='create')` | For truly novel reusable patterns |

---

## References

See `references/self-improving-agent-evaluation.md` for the session analysis of peterskoett/self-improving-agent v3.0.6 that inspired this skill's core pattern.

---

## Relationship to Other Skills

| Skill | Relationship |
|:------|:-------------|
| **darwin-skill** | Complementary. Darwin optimizes *existing* skills (quality). Meta-learning governs what gets promoted to skill/memory in the first place (genesis). |
| **systematic-debugging** | Debugging is one source of meta-learning patterns. Meta-learning says: "if you debugged this same class of issue 3 times, it's not a debugging problem, it's a knowledge problem — promote it." |
| **knowledge-architecture** | Knowledge architecture governs the *vault* structure. Meta-learning governs the agent's internal learning loop. Different scope. |
| **requesting-code-review** | Code review is a specific domain where correction patterns arise. Meta-learning's three-strike rule applies: if the same code-review finding appears ≥3 times across PRs, encode it as a permanent rule. |
