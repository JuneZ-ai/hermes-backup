# WSL Gateway Persistence

## The Root Cause

WSL 2 kills the entire WSL VM when the **last terminal window** closes. This is by design — WSL assumes no running processes means no work to do. The consequence:

- **User-level systemd** (`hermes gateway install` without `--system`): dies with the user session when terminal closes
- **System-level systemd** (`hermes gateway install --system`): also dies because **WSL itself shuts down**, taking PID 1 (systemd) with it
- Even `loginctl enable-linger` doesn't help — linger keeps the user session alive inside a running systemd, but can't prevent WSL from killing systemd entirely

The only way to keep WSL alive is to have a **running process from the Windows side** that holds a reference to the WSL VM. The `wsl.exe` process itself acts as this anchor.

## Confirmed Behavior (May 2026, Ubuntu 26.04 on WSL 2)

| Setup | Survives terminal close? | Survives WSL restart? | Survives Win reboot? | Needs admin? |
|-------|:---:|:---:|:---:|:---:|
| `hermes gateway run` (foreground) | ❌ | ❌ | ❌ | ❌ |
| `hermes gateway install` (user-level) | ❌ | ❌ | ❌ | ❌ |
| `hermes gateway install --system` | ❌ | ❌ | ❌ | ❌ |
| Windows Startup Folder VBS (bash loop) | ✅ | ❌ | ✅ (on login) | ❌ |
| Windows Scheduled Task (bash loop) | ✅ | ✅ | ✅ (auto-start) | ✅ |
| Windows Scheduled Task (`/IT` flag, no bash loop) | ❌ | ❌ | ✅ | ✅ || Windows Scheduled Task (no `/IT`, SYSTEM account, bash loop) | ✅ | ✅ | ✅ (auto-start) | ✅ |
| tmux session | ✅ | ❌ | ❌ | ❌ |

**CONFIRMED (May 2026):** The Windows Scheduled Task with `/IT` (interactive task) flag **does NOT survive** CMD/PowerShell window closure. This is confirmed through multiple real-world tests — not just theoretical. The `/IT` flag ties the task process to the user's console session (conhost.exe). When all terminal windows close, the console session terminates, killing `wsl.exe` and shutting down WSL.

**Reproduction recipe (failed every time):**
1. Create task: `schtasks /CREATE /TN HermesGateway /SC ONLOGON /DELAY 0000:30 /TR "wsl.exe ... gateway run --replace" /IT /RL HIGHEST /F`
2. Start: `schtasks /RUN /TN HermesGateway` — Gateway starts, chat works
3. Close the PowerShell/CMD window — Gateway disconnects within seconds
4. Re-open terminal — Gateway process no longer exists

**Verdict: `/IT` flag approach is BROKEN for persistence.** Always use one of:
- **VBS + bash loop** (no admin, survives terminal closure ✅)
- **Non-interactive scheduled task** with `-UserId SYSTEM -LogonType ServiceAccount` (no `/IT`, requires admin + PowerShell)

## Recommended (No Admin): Windows Startup Folder VBS + Bash Loop

If you don't have admin rights or want the simplest zero-config approach, use the **Windows Startup Folder** with a VBS script that runs a **bash keepalive loop**. This approach:
- Starts on user logon (no admin needed)
- No console window (VBS hidden mode, `0`)
- **No systemd dependency** — the bash loop keeps both WSL and the Gateway alive
- **Auto-restarts Gateway on crash** — the loop re-runs the command after a 5-second sleep
- **Survives CMD/PowerShell window closure** — the wsl.exe process is held by explorer.exe (through the startup folder), not by any terminal

### The VBS Script

Save to `%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\HermesGateway.vbs`:

```vbs
' Hermes Gateway — auto-start on Windows logon
' Bash keepalive loop: survives CMD closure, auto-restarts on crash
CreateObject("WScript.Shell").Run "wsl.exe -u hermes -d Ubuntu -- bash -c 'while true; do /usr/local/lib/hermes-agent/venv/bin/python -m hermes_cli.main gateway run --replace; sleep 5; done'", 0, False
```

- `-u hermes` — the WSL Linux user that has `~/.hermes/` configured
- `-d Ubuntu` — change to match your WSL distro name
- `bash -c 'while true; do ...; sleep 5; done'` — infinite loop keeps WSL alive and auto-restarts Gateway
- `--replace` — allows hot-swapping (new instance replaces old one)
- `0` = hidden window (no console popup)
- `False` = don't wait for process to exit

### Create from WSL

```bash
cat > "/mnt/c/Users/18502/AppData/Roaming/Microsoft/Windows/Start Menu/Programs/Startup/HermesGateway.vbs" << 'VBS'
' Hermes Gateway — auto-start on Windows logon
CreateObject("WScript.Shell").Run "wsl.exe -u hermes -d Ubuntu -- bash -c 'while true; do /usr/local/lib/hermes-agent/venv/bin/python -m hermes_cli.main gateway run --replace; sleep 5; done'", 0, False
VBS
```

Replace `hermes` with the correct WSL username, `Ubuntu` with the distro name, and the python path with the actual venv location.

### How It Works

1. Windows logs in → Explorer.exe reads the Startup folder → `wscript.exe` runs the VBS
2. VBS launches `wsl.exe` with the bash loop command (hidden, no window)
3. WSL boots, starts bash with the infinite loop
4. Each iteration: run Gateway → if it exits (crash/restart), wait 5 seconds → re-run
5. The bash loop never exits, keeping `wsl.exe` alive, which keeps the WSL VM alive
6. Closing CMD/PowerShell windows has no effect — the `wsl.exe` process is owned by the startup process chain, not any terminal

### Troubleshooting

If the Gateway doesn't auto-start after login:
1. Verify the VBS file exists at `%APPDATA%\...\Startup\HermesGateway.vbs`
2. Check if WSL works manually: `wsl -u hermes -d Ubuntu -- echo hello`
3. Try the command directly: `wsl -u hermes -d Ubuntu -- /usr/local/lib/hermes-agent/venv/bin/python -m hermes_cli.main gateway run`
4. Check Gateway logs: `cat ~/.hermes/logs/gateway.log | tail -20`
5. After login, wait ~15 seconds for WSL to fully boot, then check inside WSL: `ps aux | grep gateway`

### Limitations vs Scheduled Task

| Aspect | Startup Folder VBS (bash loop) | Scheduled Task (bash loop, admin) |
|--------|:---:|:---:|
| Requires admin | ❌ No | ✅ Yes |
| Runs before login | ❌ No (at user logon) | ✅ Yes (at system boot) |
| Survives terminal close | ✅ | ✅ |
| Survives Win reboot | ✅ (on login) | ✅ (at boot) |
| Self-healing (crash restart) | ✅ (bash loop) | ✅ (bash loop) |
| User interaction needed | None | Admin PS + password |

## Alternative (No Admin but User-Friendly): Self-Elevating Batch Script

Create a `.bat` file on the Windows Desktop that self-elevates to Administrator. The user just double-clicks it and clicks "Yes" on the UAC prompt — no right-click → Run as Administrator needed.

### The Self-Elevating .bat Script

Save to the Windows Desktop as `install-hermes-gateway.bat`:

```batch
@echo off
:: Hermes Gateway - Windows Scheduled Task Installation
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo Requesting Administrator privileges...
    powershell Start-Process "%~s0" -Verb RunAs
    exit /b
)

:: Create the scheduled task — runs wsl.exe at user logon
schtasks /Create /SC ONLOGON /TN "HermesGateway" /TR "wsl.exe -d Ubuntu" /IT /F /RL LIMITED
```

Note: This creates a user-logon-level task (not system-boot), using `schtasks` with `/IT` (interactive task) and `/RL LIMITED` (run with least privilege). This is simpler than the SYSTEM-level PowerShell script and works for most users. For true boot-time startup, use the PowerShell script in the "Full Solution" section instead.

A complete up-to-date template is at `templates/install-hermes-gateway.bat` under this skill.

## Full Solution (Admin): Windows Scheduled Task

A Windows Scheduled Task running as **SYSTEM** account executes `wsl.exe -d <distro> -u <user> <command>` at startup. As long as that `wsl.exe` / Python process lives, WSL stays alive. This is the most robust option — starts at system boot before any user logs in.

### Prerequisites

- WSL with systemd enabled (`/etc/wsl.conf` has `[boot]\nsystemd=true`)
- Gateway credentials configured (`~/.hermes/.env` with `FEISHU_*` etc.)
- Know your WSL distro name: `wsl --list --verbose`

### PowerShell Install Script

Save this as `install-hermes-gateway.ps1` on the Windows Desktop, then run from **Windows PowerShell (Administrator)**:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
C:\Users\<YourUser>\Desktop\install-hermes-gateway.ps1
```

```powershell
<#
.SYNOPSIS
    Install Hermes Gateway as a Windows Scheduled Task
.DESCRIPTION
    Creates a Windows scheduled task that starts WSL + Gateway at boot.
    The task runs as SYSTEM so it doesn't depend on any user being logged in.
    WSL stays alive because wsl.exe holds the reference.
#>

$taskName = "HermesGateway"
$distro = "Ubuntu"                  # Change to match your WSL distro
$wslUser = "hermes"                 # The Linux user that has ~/.hermes/ configured
$pythonCmd = "/usr/local/lib/hermes-agent/venv/bin/python -m hermes_cli.main gateway run"

# 1. Stop any existing systemd-based gateway (it won't survive anyway)
wsl -d $distro -u root -- systemctl stop hermes-gateway 2>$null
wsl -d $distro -u root -- systemctl disable hermes-gateway 2>$null

# 2. Create scheduled task
$action = New-ScheduledTaskAction -Execute "wsl.exe" `
    -Argument "-d $distro -u $wslUser $pythonCmd"

$trigger = New-ScheduledTaskTrigger -AtStartup
$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -RestartCount 999 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -ExecutionTimeLimit 0          # No time limit — prevents task auto-kill

$principal = New-ScheduledTaskPrincipal `
    -UserId "SYSTEM" `
    -LogonType ServiceAccount `
    -RunLevel Highest

Register-ScheduledTask -TaskName $taskName `
    -Action $action `
    -Trigger $trigger `
    -Settings $settings `
    -Principal $principal `
    -Force

Write-Host "✅ Task created: $taskName"
Write-Host "   Auto-starts WSL + Gateway at Windows boot"
Write-Host ""
Write-Host "Starting now..."
Start-ScheduledTask -TaskName $taskName
Start-Sleep 3

Write-Host "✅ Service started! Terminal closure won't affect it."
Write-Host ""
Write-Host "Management (Windows PowerShell Admin):"
Write-Host "  Stop:    Stop-ScheduledTask -TaskName $taskName"
Write-Host "  Start:   Start-ScheduledTask -TaskName $taskName"
Write-Host "  Status:  Get-ScheduledTask -TaskName $taskName | Get-ScheduledTaskInfo"
Write-Host "  Remove:  Unregister-ScheduledTask -TaskName $taskName -Confirm:`$false"
```

### Verification

After running the script:

```powershell
# Check task exists and last result
$task = Get-ScheduledTask -TaskName HermesGateway
$task | Get-ScheduledTaskInfo | Format-List

# From WSL, check gateway is running
wsl -d Ubuntu -u hermes -- ps aux | grep "gateway run"
```

**Interpreting LastTaskResult:**
| Code | Meaning |
|------|---------|
| `0` | **Success** — task completed (rare for long-running processes) |
| `1` | **Command failed** — the wsl / python command errored. Check paths and env vars |
| `4294967295` (0xFFFF00FF) | **Still starting** — task registered but the process hasn't fully launched yet. Wait a moment and re-check |
| `267009` (0x8004131F) | **Task not triggered** — check that trigger is enabled |

If LastResult is `1` persistently, inspect the WSL command in the task Actions and verify the python path exists:
```powershell
# Test the exact command the task runs
wsl -d Ubuntu -u hermes -- /usr/local/lib/hermes-agent/venv/bin/python -m hermes_cli.main gateway run --replace
```

Then check gateway logs:
```powershell
wsl -d Ubuntu -u hermes -- tail -20 ~/.hermes/logs/gateway.log
```

**Finding the task if the name varies:** Windows may create the task with a slightly different name or the script may fail silently. Search for any existing Hermes-related tasks:
```powershell
Get-ScheduledTask | Where-Object { $_.TaskName -like '*Hermes*' -or $_.TaskName -like '*hermes*' }
```

## Pitfalls

### VBS bash-loop vulnerability: process-group kill kills the watchdog

The VBS + bash-loop approach has a **single point of persistence**: the bash `while true; do ...; sleep 5; done` script. As long as this bash process runs, the Gateway restarts on crash. However:

- **`kill PID` (SIGTERM) on just the python gateway process** → the bash loop survives and respawns within 5s ✅
- **`kill -9 PID` on just the python process** → same, bash loop handles SIGKILL to its child gracefully ✅
- **`kill -9` on BOTH the python process AND the bash loop** → the VBS-launched command tree is destroyed. VBS only launched the bash loop once (`Run "...", 0, False`); it does NOT monitor or respawn it. The Gateway is permanently dead until the user manually restarts it or reboots Windows. ❌

**The VBS is not a process supervisor** — `WScript.Shell.Run` with `False` (bWaitOnReturn) creates one process and returns. If the bash loop itself is killed, the VBS can't detect that or restart it. Only the Windows Startup Folder re-runs the VBS at next login.

**If you accidentally kill the bash loop:** see the "Clean restart after full kill" section below.

### Signal nuance: `kill` (SIGTERM) vs `kill -9` (SIGKILL)

SIGTERM (`kill PID`, the default) **may not fully terminate** the gateway python process. Observed: process stays in `Rsl` state and survives `kill`, continuing to serve requests. This happens because SIGTERM is a graceful shutdown request — the `--replace` flag handler may ignore it mid-turn, or the process may be in a non-interruptible wait.

**For guaranteed termination, always use SIGKILL:**
```bash
kill -9 <pid>
# Then verify:
ps aux | grep "gateway run" | grep -v grep
# If still present, the process was in a kernel wait; retry.
```

**When the process survives SIGTERM but `kill -9` doesn't seem to work immediately**, check if there's a zombie/defunct state — those can't be killed but will be reaped when their parent (the bash loop) exits. In that case, kill the bash loop parent first:
```bash
# Find the bash while-true process
ps aux | grep "while true" | grep -v grep
kill -9 <bash_pid>  # This kills the bash loop, which reaps zombie children
```

### Clean restart after full kill (bash loop + gateway both dead)

When both the bash loop and the gateway python process are killed (e.g. `kill -9` on both PIDs), the VBS watchdog is gone and won't restart. Use this procedure:

1. **Confirm no gateway or bash-loop remnant lives:**
   ```bash
   ps aux | grep "gateway run" | grep -v grep
   ps aux | grep "while true" | grep -v grep  # confirm bash loop is dead
   ```

2. **Start a fresh bash loop via `terminal(background=true)`:**
   ```bash
   # This starts the while-true loop as a tracked background process
   # terminal(background=true, command="while true; do ...; sleep 5; done")
   ```

   Use the exact same command as the VBS script:
   ```bash
   while true; do /usr/local/lib/hermes-agent/venv/bin/python -m hermes_cli.main gateway run --replace; sleep 5; done
   ```

3. **Wait 10-15 seconds** for the gateway to boot, then verify:
   ```bash
   ps aux | grep "gateway run" | grep -v grep
   ```

4. **Handle duplicates:** Sometimes the VBS's original bash loop revives (if only the python was killed, not the bash loop). In that case you'll see two `gateway run` processes. The `--replace` flag is supposed to prevent this, but duplicates can still appear. Kill all gateway PIDs, wait 10s, and the background bash loop will start a clean single instance.

5. **Restore VBS persistence:** The background process started via `terminal(background=true)` is scoped to the agent turn — it dies when the conversation turn ends. To make it persistent again, restart the VBS script's bash loop manually (same command as above) in a tmux session:
   ```bash
   tmux new-session -d -s hermes-gw-recovery \
     'while true; do /usr/local/lib/hermes-agent/venv/bin/python -m hermes_cli.main gateway run --replace; sleep 5; done'
   ```
   This survives across agent turns and terminal closures.

### The `--replace` flag kills the gateway under systemd

When the gateway is started with `--replace`, it interprets SIGTERM as "a new instance is taking over — exit cleanly". Under systemd, SIGTERM is sent during normal lifecycle (restart, stop), so **the gateway exits instead of restarting**.

**Diagnostic log signature:** Look for this line in `gateway.log` or `journalctl`:
```
INFO gateway.run: Received SIGTERM as a planned --replace takeover — exiting cleanly
```
Combined with `parent_name=systemd` in the shutdown context, this confirms the `--replace` flag is causing premature exits under systemd.
```
WARNING gateway.run: Shutdown context: signal=SIGTERM under_systemd=yes parent_pid=1 parent_name=systemd ...
```

**Consequence:** Systemd's `Restart=always` immediately spawns a new process, but it also receives SIGTERM → exit → restart → SIGTERM → exit → crash loop. The service shows:
```
Active: activating (auto-restart) (Result: exit-code)
```

**Fix:** Remove `--replace` from `ExecStart` when running under systemd:

```
# BAD — exits on SIGTERM:
ExecStart=... gateway run --replace

# GOOD — systemd handles lifecycle:
ExecStart=... gateway run
```

The `--replace` flag is only appropriate for manual hot-swapping (e.g. `hermes gateway run --replace` in a terminal to replace a foreground process).

**Crash-loop recovery (when you can't run sudo):** If the systemd service is stuck in auto-restart, stop it from Windows PowerShell — this sends commands through `wsl.exe` with root privileges without needing a TTY:

```powershell
wsl -d Ubuntu -u root -- systemctl stop hermes-gateway
wsl -d Ubuntu -u root -- sed -i 's/ --replace//' /etc/systemd/system/hermes-gateway.service
wsl -d Ubuntu -u root -- systemctl daemon-reload
wsl -d Ubuntu -u root -- systemctl restart hermes-gateway
```

Or if switching to the Windows Scheduled Task approach (recommended), the install script handles this automatically.

### Don't use `systemctl --user` for management

User-level systemd on WSL is unreliable — it dies whenever the last terminal closes. Always use the Windows Scheduled Task approach above, or the simpler Startup Folder (VBS) approach as a no-admin alternative.

### Script location

The `.ps1` script belongs on the Windows Desktop (accessible at `/mnt/c/Users/<user>/Desktop/` from WSL). Do NOT keep it in the WSL filesystem — the user needs it accessible from Windows PowerShell.

### UAC elevation cannot be triggered from WSL bash

When running from inside WSL (bash), attempting to launch an elevated process via PowerShell fails:

```bash
# From WSL bash — will NOT work:
powershell.exe -Command "Start-Process cmd -Verb RunAs -ArgumentList '/c', 'C:\path\to\script.bat'"
# → Error: "操作被用户取消" (Operation canceled by user)
```

**Root cause:** The `Start-Process -Verb RunAs` command spawns a UAC dialog on the Windows desktop. However, the caller is a non-interactive terminal session (WSL's bash), and the UAC dialog cannot be associated with an interactive window station. The dialog appears but immediately times out or is auto-denied because it has no parent window to interact with.

**This is a consistent behavior across WSL → Windows elevation attempts** — not a transient failure. The UAC API requires the calling process to have an interactive Win32 window station, which WSL processes do not have.

**Workarounds:**
1. **Self-elevating .bat** (recommended) — Create a `.bat` file on the Windows Desktop that self-elevates via `powershell Start-Process "%~s0" -Verb RunAs`. The UAC prompt appears when the user double-clicks the `.bat` in Windows Explorer (which has a proper window station). See the "Alternative (No Admin but User-Friendly)" section above.
2. **Manual elevation** — Tell the user to right-click the PowerShell script → "Run as Administrator" in Windows Explorer.
3. **VBS startup folder** — For the simpler use case (start WSL on logon), the VBS approach in the Startup Folder needs no admin rights at all.
4. **Create the script file from WSL, have user run it from Windows** — Write the `.ps1` or `.bat` to the Windows Desktop from WSL, then instruct the user to run it on the Windows side.

**You CAN create the file from WSL on the Windows Desktop** (e.g., `/mnt/c/Users/<user>/Desktop/install-task.ps1`), then tell the user to double-click the `.bat` or right-click the `.ps1`. This is the correct pattern. Do NOT attempt to invoke UAC elevation from WSL.

## Alternative: tmux (for development/testing only)

```bash
tmux new-session -d -s hermes-gw 'hermes gateway run'
```

After reboot: `tmux attach -t hermes-gw`. Not suitable for production use — requires manual reattachment.
