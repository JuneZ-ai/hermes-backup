# WB 用户级技能库审计结果（2026-05-29）

审计范围：`C:\Users\18502\.workbuddy\skills\`（用户级，全局）

## 🔴 立即删除（10个）

| # | 技能名 | 原因 |
|:-:|:-------|:-----|
| 1 | dna-memory | Hermes已有同名skill + 原生memory系统 |
| 2 | excalidraw-diagram | Hermes已有 `excalidraw` skill |
| 3 | infographic-maker | Hermes已有 `baoyu-infographic` |
| 4 | textual-alchemist | Hermes已有 `wenyuanjiang-ocr-pipeline` |
| 5 | model-router | Hermes已有 `task-driven-model-routing` |
| 6 | skill_2053082253572640768 | lark-unified → Hermes有全套Lark工具 + lark-cli |
| 7 | tavily | Hermes自身搜索(web_search)更强 |
| 8 | translator | LLM内置翻译能力 |
| 9 | filesystem-mcp | Hermes有原生文件工具集 |
| 10 | soskill | 空壳SKILL.md，已废弃 |

## 🟡 建议删除（5个）

| # | 技能名 | 原因 |
|:-:|:-------|:-----|
| 11 | find-skills | Hermes用skills_list/skill_view管理，WB不需要独立发现 |
| 12 | color-palette-cn | 标注claude-code-only，WB中无法运行 |
| 13 | obsidian-vault-setup | 一次性搭建，非持久技能 |
| 14 | agent-browser | Hermes有Chrome DevTools MCP浏览器能力，功能重叠 |
| 15 | competitor-watch | 持续监控型，Hermes cron + web_search可替代 |
| 16 | brainstorm | "生成想法"即LLM默认能力，WB不需要单独技能 |

## 🟢 保留（15个）

| # | 技能名 | 保留原因 |
|:-:|:-------|:---------|
| 1 | 六韬易哲 | 自建易学智能体，核心资产 |
| 2 | 六韬智脑 | 自建战略顾问"任老" |
| 3 | 元认知引擎 | 自建认知警戒模块 |
| 4 | 小布 | 自建通路执行者 |
| 5 | 周报生成 | WB自动化调用的周报技能 |
| 6 | api-gateway | WB生态核心-1092个免费API智能调度 |
| 7 | competitor-analysis-report | 竞品深度分析（一次性，与competitor-watch不同） |
| 8 | content-repurposer | 多平台内容分发管线 |
| 9 | market-researcher | 市场调研(TAM/SAM/SOM) |
| 10 | design-brand-visual | 品牌视觉设计 |
| 11 | visual | 品牌视觉设计(含SVG/Tailwind色板) |
| 12 | poster | 海报生成(each::sense AI独立平台) |
| 13 | prd | 产品需求文档生成 |
| 14 | skill-vetter | WB生态技能安全审计 |
| 15 | skill_2053082035554123776 | GitHub Trending监控 |

## 审计方法要点

- 读取每个技能SKILL.md的完整description，**非仅看技能名**
- 关注 trigger_words/trigger_keywords 以确定实际使用场景
- 持续性监控类技能（competitor-watch）优先对照Hermes cron能力
- 自建技能（六韬系列）无条件保留
- WB自动化依赖的技能（周报生成）在确认依赖前不删
