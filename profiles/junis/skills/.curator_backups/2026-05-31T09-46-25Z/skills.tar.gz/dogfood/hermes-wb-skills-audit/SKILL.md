---
name: hermes-wb-skills-audit
description: 审计 WorkBuddy 技能库，找出已被 Hermes 替代的冗余技能以降低积分消耗。当用户要求给 WB 瘦身、减负、减少积分消耗时使用。核心：对照 Hermes 已有能力逐项评估。
trigger_keywords:
  - WB瘦身
  - WB技能审计
  - WorkBuddy积分
  - WB减负
  - Hermes-WB冗余
  - 技能去重
  - WB skill audit
  - WB skills cleanup
---

# Hermes-WB 技能冗余审计

## 审计流程

### 第一步：定位 WB 技能目录

WB 有两种技能目录，分开审计。**从用户级开始排查**（项目级目录下是 zip 包而非已安装的技能）：

| 范围 | 路径（从 WSL） | 说明 |
|:----|:--------------|:-----|
| 🔴 **用户级（首选）** | `/mnt/c/Users/18502/.workbuddy/skills/` | 全局技能，**这是真正安装技能的地方** |
| 🟡 项目级 | `/mnt/c/Users/18502/WorkBuddy/projects/<project>/skills/` | 含未安装的 zip 压缩包，不是活跃技能 |

> ⚠️ **注意区分：** `WorkBuddy/` 项目目录下是 zip 包和项目文件，`.workbuddy/skills/` 才是已安装的活跃技能。用户指出过这个区别。

### 第二步：读取每个技能的描述

对每个技能目录，读取 `SKILL.md` 中的 `description` 字段（可能含 trigger_words/trigger_keywords）。

> ⚠️ **不要只看技能名猜测功能！** 技能名可能误导。必须读 description 全文，特别关注：
> - `trigger_words` / `trigger_keywords` — 哪些场景会触发它
> - `read_when` — 何时被加载
> - `compatibility` — 如 `claude-code-only` 的说明
> - 是否标注持续性/监控型（如 "on an ongoing basis"）而非一次性的

### 第三步：三类判断

| 类别 | 判断标准 | 行动 |
|:----|:---------|:-----|
| 🔴 **可删除** | Hermes 有原生工具/skill 完美替代，转 Hermes 后 WB 不再需要 | 直接删目录 |
| 🟡 **建议删除** | Hermes 能处理，或一次性工具，或标注其他平台独占无法在 WB 运行 | 可删，留记录 |
| 🟢 **保留** | WB 生态独有 / 持续调用的 WB 自动化依赖 / 自建核心资产 | 不动 |

### 第四步：关键判断启发式

判断一个 WB 技能是否冗余时，问以下几个问题：

1. **Hermes 是否有同功能 skill？** → `skills_list` 检查
2. **Hermes 是否有同功能原生工具？** → 如搜索(search → web_search/web_search)、浏览器(Chrome DevTools MCP)、文件操作(file tools)、翻译(LLM自身)
3. **该技能的核心工作流是否已迁移到 Hermes？** → 用户目前已全面使用 Hermes 做日常任务
4. **该技能是否由 WB 自动化主动调用？** → 如果是（如周报生成、每日寓言），则保留；如果只是被动等用户召唤，可删
5. **该技能是自建核心资产吗？** → 六韬智脑/六韬易哲/元认知引擎/小布 等需保留
6. **该技能是否标注了仅其他平台可用？** → 如 `compatibility: claude-code-only` → 在 WB 中实际为死技能

### 第五步：清理方式

```bash
# 删除一个技能目录
rm -rf "/mnt/c/Users/18502/.workbuddy/skills/<技能名>"
```

---

## 已知冗余汇总（已审计，可引用）

参见 `references/2026-05-29-wb-skills-audit-results.md`

---

## Pitfalls

- 🚫 **不要仅凭技能名做判断** — `competitor-watch` 名似分析，实为持续监控（Hermes cron 可替代）
- 🚫 **不要遗漏 trigger_words** — 读 full description，触发词决定技能实际使用场景
- 🚫 **不要删除 WB 自动化正在引用的技能**（如周报生成）— 先确认 cron/automation 是否依赖
- 🚫 **不要删除自建核心资产**（六韬系列）— 它们是知识库延伸，非通用工具
- 🚫 **不要假设 "不常用 = 可删"** — 某些技能虽低频但无可替代（如 poster 依赖 each::sense AI 独立平台）
