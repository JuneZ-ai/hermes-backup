# Vault Health Audit — 知识库体检流程

当用户问「检查一下知识库有没有问题」「看看哪里需要优化」时，执行本流程。

## 扫描清单（按顺序）

### 1. 总量统计
```bash
# 总笔记数
find . -name "*.md" -not -path "./.obsidian/*" | wc -l
# 按目录分布
for dir in $(find . -type d -not -path "./.obsidian/*" | sort); do
  count=$(find "$dir" -maxdepth 1 -name "*.md" | wc -l)
  [ "$count" -gt 0 ] && echo "$dir: $count"
done
# 空文件
find . -name "*.md" -not -path "./.obsidian/*" -size -50c
```

### 2. 总纲一致性检查
- 树形图列出的笔记是否都存在？
- 统计表（笔记数、Deep-Dive、状态）是否与实际情况一致？
- 使用场景速查表的链接是否有效？

### 3. 断链检测

关键：区分**相对路径链接**（`[[../../note]]` — Obsidian 能解析）和**真断链**（文件不存在）。

```bash
# 提取所有 [[wikilink]] 并检查文件是否存在
grep -rohP '\[\[[^\]]+\]\]' --include="*.md" . | \
  sed 's/\[\[//' | sed 's/\]\]//' | sed 's/|.*//' | \
  sed 's/\\\|.*//' | sort -u | while read link; do
    echo "$link" | grep -qE '^(http|www|#)' && continue
    found=$(find . -path "*/$link.md" 2>/dev/null | head -1)
    [ -z "$found" ] && echo "BROKEN: [[$link]]"
  done
```

### 4. 孤岛笔记检测

查找没有任何其他笔记引用的文件：

```bash
for f in $(find . -name "*.md" -not -path "./.obsidian/*"); do
  basename=$(basename "$f" .md)
  inlinks=$(grep -rl "\[\[$basename" --include="*.md" . | grep -v "$f" | wc -l)
  [ "$inlinks" -eq 0 ] && echo "ORPHAN: $f"
done
```

**注意排除**：欢迎页、_标准规范文件、专用模板等按设计可以是孤岛。

### 5. 缺少 index.md

```bash
for dir in $(find . -type d -not -path "./.obsidian/*"); do
  count=$(find "$dir" -maxdepth 1 -name "*.md" | wc -l)
  if [ "$count" -gt 1 ] && [ ! -f "$dir/index.md" ]; then
    echo "MISSING INDEX: $dir ($count notes)"
  fi
done
```

### 6. wiki 概念入链覆盖率

```bash
for w in 概念1 概念2 概念3; do
  count=$(grep -rl "wiki/$w" --include="*.md" . | grep -v "wiki/$w" | wc -l)
  echo "[[wiki/$w]] → $count inbound links"
done
```

### 7. 非 .md 文件检查

```bash
find . -maxdepth 1 -not -name "*.md" -not -name "." -not -path "./.obsidian" -not -path "./.*"
```

Obsidian 有时会创建 `.base`（Obsidian Base 插件）、`.canvas`（Canvas 插件）、`.excalidraw`（Excalidraw 插件）等文件。这些不应称为孤岛，但应检查是否需要重命名和链接。

## 报告产出格式

按严重程度分组：

| 标记 | 含义 | 行动 |
|:----:|------|------|
| 🔴 | 断链 / 关键入口缺失 | 必须修复 |
| 🟡 | 缺 index / wiki 入链薄弱 | 建议修复 |
| 🟢 | 发现但按设计可接受 | 仅报告 |

## 修复优先级

1. **断链** — 总纲是最重要的导航页，优先修复其中的坏链
2. **总纲统计表** — 确保数字与现实一致
3. **缺 index.md** — 每个有 2+ 笔记的目录都应该有导航
4. **孤岛接入** — 核心规范文档（如 frontmatter 规范）应接入欢迎页或总纲
5. **wiki 补链** — 在相关笔记末尾加上 `→ 参见 [[wiki/xxx]]` 一行

## 树形图维护技巧（总纲 00-总纲.md）

总纲用 ASCII 树形图（代码块中）列举所有笔记条目，维护时有几个坑：

### 添加新条目

1. 找到当前 `└──`（最后一个条目）
2. 把 `└──` 改成 `├──`
3. 在下一行新增 `└──` 条目
4. 注意管道符转义：patch 工具的 old_string 从 `read_file` 输出完整复制（含 `\|`），new_string 手动写 clean 版本

```
# 示例扩展树形图
patch(path="00-六韬总纲.md",
  old_string="│   └── **[[六韬智脑/20-格局逆袭制胜之道\\|格局逆袭·宗宁]]**",
  new_string="│   ├── **[[六韬智脑/20-格局逆袭制胜之道\\|格局逆袭·宗宁]]**\n│   └── **[[六韬智脑/21-Karpathy认知框架\\|凯帕西·AI思维框架]]**")
```

### 常见转义陷阱

| 想要显示 | 文件中实际字符 | patch old_string 写法 |
|---------|---------------|---------------------|
| `\|` (管道符) | `\|` | 从 read_file 原文复制 |
| 换行 | 实际换行符 | 用 `\n` 或直接写多行 |
| `\` (反斜杠) | `\` | `\\` |

**黄金法则**：old_string 从 `read_file` 输出复制（直接复制渲染后的内容），never 手动拼写转义序列。new_string 可以手动写。

### 统计表同步

修改树形图后务必检查三处：
- 模块状态表的笔记数是否更新
- Deep-Dive 列表是否加了新条目名
- 模块状态（🟢/🟡）是否需调整
