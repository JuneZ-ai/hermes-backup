# Web Content Extraction · 网页内容提取

当源文本是网页链接（非 PDF/本地文件）时，需要先提取内容。

## 问题：JS 渲染屏障

今日头条、微信公众号、百度等国内主流网站强依赖 JavaScript 渲染内容。
直接 `curl` / `urllib` 请求只能拿到 HTML 骨架和混淆脚本，拿不到正文。

## 提取策略（优先级排序）

### 策略 A：搜索引擎跳板（推荐首选）

当源站无法直接抓取时，通过搜索引擎找替代来源：

1. **用搜狗搜索**（对微信/头条收录较全）
   ```
   https://www.sogou.com/web?query={文章标题/关键词}
   ```
2. **查找结果中的微信公众号文章**（`mp.weixin.qq.com` 链接）
3. **访问微信公众号文章**——通常可以正常抓取正文
4. 搜狗也会将微信文章 URL 中的 `signature` 参数部分屏蔽为 `***`，但完整 URL 仍然在 HTML 的 `href` 属性中可提取

### 策略 B：多搜索引擎轮询

```python
# 尝试多个搜索引擎
for engine, url_template in [
    ("Sogou", "https://www.sogou.com/web?query={}"),
    ("Bing", "https://cn.bing.com/search?q={}"),
]:
    full_url = url_template.format(urllib.parse.quote(query))
    # 请求 → 解析 → 提取链接和摘要
```

### 策略 C：移动端/API 尝试

部分网站的移动端 API 限制较少：
- `m.toutiao.com` 可能有不同于 `www.toutiao.com` 的 API 端点
- 腾讯新闻（`newsa.html5.qq.com`）的视频页面会有 title 和 description

### 策略 D：子代理 + browser 工具集

如果上述都失败，可用 `delegate_task` 启动带有 `browser` 工具集的子代理：
- 子代理可以使用 headless 浏览器渲染 JS 页面
- 但需要注意：browser 工具集可能需要额外安装依赖

## 微信公众号文章提取（最稳定的来源）

微信公众平台的页面（`mp.weixin.qq.com`）通常可以正常抓取到 HTML 正文。
抓取后，提取 `id="js_content"` 或 `class="rich_media_content"` 的 div 内容即可。

```python
import re
with open('page.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 提取文章标题
title_match = re.search(r'var\s+msg_title\s*=\s*["\'](.*?)["\']', html)
title = title_match.group(1) if title_match else ""

# 提取正文内容
content_match = re.search(r'id="js_content"[^>]*>(.*?)</div>\s*<script', html, re.DOTALL)
if content_match:
    text = re.sub(r'<[^>]+>', '\n', content_match.group(1))
    text = re.sub(r'&nbsp;', ' ', text)
    text = re.sub(r'\n\s*\n', '\n', text)
```

## 注意事项

- 不要被搜索引擎的「无法访问」吓退——改用不同的 User-Agent 和 Referer
- 搜狗搜索返回的结果中，URL 的 `signature` 参数会被部分屏蔽为 `***`，但 `href` 属性中保留完整 URL
- 今日头条的页面防爬极严（混淆 JS + 动态加载），通过搜索引擎找转载是更高效的路径
- 页面抓取有法律合规风险，仅用于学习/研究目的
