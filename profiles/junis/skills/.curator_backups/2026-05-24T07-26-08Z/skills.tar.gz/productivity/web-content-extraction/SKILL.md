---
name: web-content-extraction
description: 从复杂网页（JS渲染/SPA/视频号/动态页面）中提取可读文本内容的工具体系和方法论。覆盖多种网页类型和提取策略，按可靠性排序。
version: 1.0.0
tags: [web-scraping, content-extraction, readability, js-rendering, wechat, knowledge-ingestion]
---

# Web Content Extraction

从复杂网页中提取纯净可读文本，供知识库入库或 LLM 处理。这是一个多策略体系，按可靠性从高到低排列。

## 核心原则

1. **先搜工具，不自己折腾** —— 遇到复杂链接（JS渲染/反爬/视频号），先去GitHub搜现成方案，不要自己写爬虫或试错调试
2. **选最简单的方案** —— 能用Jina Reader就别装Playwright，能装一个pip包就别搞MCP Server。收到"太复杂"的反馈时，立刻切换到更简单的方案
3. **不要死磕** —— 如果所有工具都打不开（视频号需要登录态、付费墙等），直接让用户分享文字版。这不是失败，是务实

## 触发场景

- 用户分享一个链接，要求"读了入库"或"提取内容"
- 链接是 JS 渲染页面（视频号、SPA、动态站点）
- 常规 curl/wget 只能抓到 HTML 外壳（~2KB）
- 需要提取的内容被广告/导航/弹窗包裹

## 提取策略体系（按优先级排列）

### 1️⃣ Trafilatura（首选，零依赖）

```bash
# 安装
pip3.14 install --break-system-packages trafilatura

# 使用
python3.14 -c "
import trafilatura
url = 'https://example.com'
downloaded = trafilatura.fetch_url(url)
if downloaded:
    text = trafilatura.extract(downloaded, output_format='txt')
    if text: print(text)
"
```

- **适用**：普通微信公众号文章、博客、新闻等静态 HTML 页面
- **不适用**：JS 渲染页面（视频号、SPA）
- **优势**：纯 Python，无需浏览器，毫秒级返回

### 2️⃣ Jina Reader API（零安装，JS 渲染）

```bash
curl -sL --max-time 30 "https://r.jina.ai/https://example.com" \
  -H "Accept: text/plain"
```

- **适用**：普通 JS 渲染页面
- **不适用**：需要登录态的内容（微信视频号、付费墙）
- **优势**：免费，无需安装，云端渲染 JS
- **注意**：可能被部分网站限流或超时

### 3️⃣ Playwright + Trafilatura（url2md4ai）

GitHub: [mazzasaverio/url2md4ai](https://github.com/mazzasaverio/url2md4ai)

```bash
# 安装
git clone https://github.com/mazzasaverio/url2md4ai.git
cd url2md4ai
pip install -e .
playwright install chromium
# 使用
url2md4ai convert "https://example.com" --no-save
```

- **适用**：复杂 SPA、需要 JS 渲染的页面
- **限制**：当前环境（Ubuntu 26.04）Playwright 不支持 chromium 安装
- **替代方案**：手动下载 Chromium 或使用 Windows 端 Chrome

### 4️⃣ Chrome DevTools Protocol（CDP）

通过 npm 安装 `chrome-devtools-mcp`:

```bash
npm install -g chrome-devtools-mcp
chrome-devtools-mcp --headless
```

- **适用**：需要完整浏览器环境的页面
- **限制**：需要 Chrome/Chromium 可执行文件
- **WSL 环境**：Windows 端 Chrome 通过 CDP 端口映射不稳定（防火墙问题）

### 5️⃣ EasyOCR（截图/图片文字提取）

当用户发送了页面截图（长图）时，用 EasyOCR 进行本地 OCR 提取文字：

```bash
# 安装（~600MB，含 PyTorch，需设置 TMPDIR）
TMPDIR=/home/hermes/tmp pip3.14 install --break-system-packages --no-cache-dir easyocr

# 使用
python3.14 -c "
import easyocr
reader = easyocr.Reader(['ch_sim', 'en'], gpu=False)
results = reader.readtext('/path/to/screenshot.jpg', detail=1, paragraph=True)
for _, text, _ in results: print(text)
"
```

- **适用**：用户发送的截图、长图、翻拍照片
- **优势**：无需浏览器、无需网络，纯本地处理
- **限制**：
  - 首次运行时需要从 GitHub 下载模型文件（~100MB），当前 WSL 环境 GitHub 不可访问
  - 需要 PyTorch（~500MB），/tmp 磁盘空间需足够（1.9G 勉强，建议 TMPDIR=/home/hermes/tmp）
  - CPU 模式较慢，长图（9000px+）需数分钟
- **⚠️ GitHub 被墙的替代方案**：如果模型下载失败，尝试从百度/Bing搜索找到的文字版替代，或使用 Bing 搜索同一内容的文本版本

### 6️⃣ 搜索引撃回退（最后手段）

当直接提取失败时，尝试用搜索引擎查找相同内容：

```python
import urllib.request, urllib.parse
query = urllib.parse.quote('文章中的核心引用语或标题')
url = f'https://www.bing.com/search?q={query}'
req = urllib.request.Request(url, headers={'User-Agent': '...'})
```

- **注意**：Bing 可访问（Google 在 WSL 中 network unreachable）

### 6️⃣ 直接请求用户提供文字版

如果以上全部失败，直接请用户粘贴文字内容。这不是失败——对需要登录态的内容（微信视频号、付费文章），这是唯一可靠的途径。

## WeChat 特定策略

| 类型 | URL 模式 | 提取方法 | 说明 |
|------|---------|---------|------|
| 公众号文章 | `mp.weixin.qq.com/s/...` | Trafilatura（直接抓）或 wechat-article-exporter | 加移动端UA可绕过WAF |
| 视频号 | `weixin.qq.com/sph/...` | **无法自动提取** | 需要微信登录态，Jina超时，浏览器CDP也抓不到。直接让用户分享文字版 |
| 视频号（内部URL） | `channels.weixin.qq.com/finder-preview/pages/sph?id=...` | 同上 | yt-dlp 能识别该链接但无法提取内容，因无对应 extractor |

### 视频号处理流程（全部失败时的完整路径）

当收到 `weixin.qq.com/sph/...` 链接时，按以下顺序尝试：

1. **Jina Reader** `curl -sL --max-time 30 "https://r.jina.ai/<url>"` — 可能超时（需微信登录态）
2. **Trafilatura** `python3.14 -c "import trafilatura; ..."` — 只会抓到 2KB HTML 框架
3. **yt-dlp 探路** — `python3.14 -m yt_dlp --dump-json <url>` 确认是否为视频号并获取内部 URL
4. **Bing 搜索**引用语/标题找相同内容
5. **OCR 截图** — 如果用户同时提供了截图（长图），尝试用 EasyOCR 读取：
   ```bash
   python3.14 -c "
   import easyocr
   reader = easyocr.Reader(['ch_sim', 'en'], gpu=False)
   results = reader.readtext('/path/to/screenshot.jpg', detail=1, paragraph=True)
   for _, text, _ in results: print(text)
   "
   ```
   - ⚠️ EasyOCR 首次运行需要从 GitHub 下载模型文件（~100MB），当前 WSL 环境 GitHub 不可访问。如安装失败，告知用户并提供备选方案。
6. **直接请求文字版** — 上述均失败后，告诉用户这是视频号内容、需要登录态无法自动提取，请分享文案文字版

## 用户偏好

- **优先简单方案**：用户明确偏好"选择简单的方案"——不要为复杂页面搭建重型工具链
- **先搜索GitHub**：用户要求遇到新问题时"直接去找一个好用的技能"，而不是自己调试摸索
- **务实交付**：工具抓不到就如实说明原因，建议用户提供文字版

## 环境约束（WSL + Ubuntu 26.04）

1. **系统 Python 路径**：`/usr/bin/python3.14` 使用 `--break-system-packages`
2. **Hermes venv**：`/usr/local/lib/hermes-agent/venv/bin/python3` — 权限受限，pip install 可能 Denied
3. **Playwright**：不支持 Ubuntu 26.04，无法 `playwright install chromium`
4. **Google**：WSL 中 network unreachable（curl 超时）
5. **GitHub**：WSL 中 network unreachable（模型下载、git clone 均失败）
6. **Bing / 百度**：可用
7. **Jina Reader (r.jina.ai)**：可用但对视频号链接超时
8. **npm**：可用（`/home/hermes/.local/bin/npm`）
9. **pip3.14**：可用（`python3.14 -m pip install --break-system-packages`）
10. **Windows Chrome**：位于 `/mnt/c/Program Files/Google/Chrome/Application/chrome.exe`
    - 可通过 `cmd.exe /c start /b ...` 后台启动
    - CDP 端口（9222）从 WSL 访问可能被防火墙拦截，连接不稳定
    - WSL→Windows 进程调用 exit code 57（DLL依赖问题）
11. **Windows Tesseract OCR**：位于 `/mnt/c/Program Files/Tesseract-OCR/tesseract.exe`
    - 同 Chrome 一样 WSL→Windows 进程启动不稳定
12. **Puppeteer Chrome 缓存**：`/home/hermes/.cache/puppeteer/chrome/` — 二进制可能为空
13. **磁盘空间**：根分区 947G 可用，但 `/tmp` 仅 1.9G（需设置 TMPDIR 到 home）

## 参考

- [references/github-tools.md](references/github-tools.md) — GitHub 上发现的相关工具详情
- [obsidian-ingestion-pipeline](../note-taking/obsidian-ingestion-pipeline/SKILL.md) — 提取后的接入流程
- [ocr-and-documents](../productivity/ocr-and-documents/SKILL.md) — 图片/PDF/扫描件提取替代方案
