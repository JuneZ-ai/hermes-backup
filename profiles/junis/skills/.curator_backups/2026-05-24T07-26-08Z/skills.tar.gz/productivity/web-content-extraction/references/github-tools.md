# GitHub 网页内容提取工具清单

本会话（2026-05-23）中从 GitHub 搜索发现的网页内容提取工具。

## url2md4ai — ⭐ 最推荐

| 属性 | 值 |
|------|-----|
| **仓库** | [mazzasaverio/url2md4ai](https://github.com/mazzasaverio/url2md4ai) |
| **语言** | Python |
| **引擎** | Playwright（JS 渲染）+ Trafilatura（内容提取） |
| **输出** | 纯净 Markdown |
| **接口** | CLI + Python API |
| **描述** | "Lean Python tool for extracting clean, LLM-optimized markdown from web pages. Handles dynamic content with Playwright + Trafilatura." |
| **安装** | `pip install url2md4ai` → `playwright install chromium` |
| **使用** | `url2md4ai convert "https://example.com" --no-save` |
| **亮点** | 97% 噪声缩减（51KB→9KB），去广告/导航/Cookie 横幅 |
| **限制** | 需要 Playwright + Chromium，当前环境不支持 |

## trawl — 高级选手

| 属性 | 值 |
|------|-----|
| **仓库** | [bbulb/trawl](https://github.com/bbulb/trawl) |
| **语言** | Python |
| **引擎** | Playwright + Trafilatura + BeautifulSoup（三路）+ bge-m3 嵌入 |
| **核心能力** | 选择性提取：给 URL + 查询，只返回最相关的 chunk（~1k tokens） |
| **接口** | Python API + stdio MCP Server |
| **亮点** | 23× token 压缩率（vs Jina Reader），自托管，heading-aware chunking |
| **基准** | F1=0.777 on WCXB（1,497 页面基准）vs Trafilatura 0.750 |
| **MCP 工具** | `fetch_page`（提取）、`profile_page`（CSS选择器分析） |
| **限制** | 需要 bge-m3 嵌入服务器，首次加载约 9s 延迟，配置重 |

## jinab — Jina Reader CLI

| 属性 | 值 |
|------|-----|
| **仓库** | [ominiverdi/jinab](https://github.com/ominiverdi/jinab) |
| **语言** | Rust |
| **本质** | Jina Reader API 的 CLI 封装 |
| **使用** | `jinab read https://example.com` |
| **功能** | 读网页 + 搜索，支持 JSON 输出、管道 |
| **限制** | 需要 Jina API Key，Rust 编译，和直接 curl Jina 效果相同 |

## chrome-devtools-mcp — CDP 控制

| 属性 | 值 |
|------|-----|
| **包名** | `chrome-devtools-mcp`（npm） |
| **安装** | `npm install -g chrome-devtools-mcp` |
| **功能** | 通过 Chrome DevTools Protocol 控制浏览器 |
| **用法** | `chrome-devtools-mcp --headless`（自动管理 Chrome 实例） |
| **配置** | 可注册为 Hermes MCP server |
| **检查** | 当前环境已安装 `npm`，`chrome-devtools-mcp` 已全局安装 |

## 其他发现

- **scotteh/php-goose** — PHP 版的 Readability/文章提取器（不适用，环境无 PHP）
- **Murrough-Foley/rs-trafilatura-python** — Rust 版 Trafilatura 的 Python 绑定
- **core-mfg/websearch** — 基于 Trafilatura 的搜索+提取包
- **sheryc/jina-reader-extension** — Chrome 扩展，Jina Reader API 浏览器插件
- **JoshuaOliphant/Link-Content-Scraper** — Jina Reader 的 FastAPI 包装服务
