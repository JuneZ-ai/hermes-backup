# 飞书 /file/ 类型文档读取方法

当用户在飞书 DM 中分享 `/file/` 类型链接（如 `https://my.feishu.cn/file/W8A9b...`），且 `feishu_doc_read` 工具不可用时，通过飞书 Drive API 直接下载。

## 识别文档类型

- 链接含 `/docx/` → docx 文档，用 `/open-apis/docx/v1/documents/{id}/raw_content`
- 链接含 `/file/` → Drive 文件（可能为 PDF/文本/图片等），用 Drive 下载 API
- 链接含 `/sheet/` → 电子表格
- 链接含 `/base/` → 多维表格
- 链接含 `/wiki/` → 知识库页面

## 读取 /file/ 文档步骤

### 1. 获取 tenant_access_token

```bash
source ~/.hermes/.env
TOKEN=$(curl -s -X POST "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" \
  -H "Content-Type: application/json" \
  -d "{\"app_id\":\"$FEISHU_APP_ID\",\"app_secret\":\"$FEISHU_APP_SECRET\"}" | \
  python3 -c "import sys,json; print(json.load(sys.stdin)['tenant_access_token'])")
```

### 2. 下载文件

```bash
DOC_TOKEN="W8A9b1Sl..."  # 从URL提取
curl -s "https://open.feishu.cn/open-apis/drive/v1/files/${DOC_TOKEN}/download" \
  -H "Authorization: Bearer $TOKEN" \
  -o /tmp/feishu_download.bin
```

### 3. 检查文件类型

```bash
file /tmp/feishu_download.bin
```

文本文件直接 `cat` 或 `read_file`；二进制文件需进一步处理（PDF→pymupdf，图片→vision_analyze）。

### 4. 读取内容

```bash
cat /tmp/feishu_download.bin
```

或

```bash
cp /tmp/feishu_download.bin /tmp/feishu_content.md
# then read_file /tmp/feishu_content.md
```

## 常见错误

| 错误码 | 含义 | 处理 |
|--------|------|------|
| 10014 | app_secret 无效 | 检查 `.env` 文件中的真实 secret（终端输出可能被截断） |
| 1770002 | 文档类型不匹配 | 确认文档是 docx 还是 file 类型，换 API |
| 404 | token 不存在/无权限 | 可能是 file token 已过期或被删除 |

## 注意

- `FEISHU_APP_SECRET` 在环境变量中可能显示为 `qSk4tz...VaHN`（省略号），但 `.env` 文件中是完整值
- 用 `source ~/.hermes/.env` 加载真实值而非直接复制 env 输出
- tenant_access_token 有效期约 2 小时，每次使用前重新获取
