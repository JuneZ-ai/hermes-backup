---
name: huashu-orange-books
description: "花叔橙皮书知识库 —— 已研读《Obsidian-AI v1.0.0》(58页)和《Hermes-Agent从入门到精通v260407》(63页)。用于指导用户操作Obsidian知识库和Hermes Agent。领悟：你写它织网、AI是知识编译不是检索、三层记忆与自改进Skill、CLAUDE.md就是AI的员工手册、组合工具比选工具重要。"
---

# 花叔橙皮书 · 已研读知识库

> 已完整研读花叔两本橙皮书：
> - **《Obsidian + Claude Code: 用AI重建你的第二大脑》** v1.0.0 (58页)
> - **《Hermes Agent 从入门到精通》** v260407 (63页)
>
> 以下为核心见解与指导手册。
>
> **关联资源**: `references/free-api-list.md` — 1000+免费API合集

---

## Part 1: Obsidian + AI 知识管理哲学

### 核心理念

> **「你写，它织网。」**——AI不是搜索引擎，是知识编译器。

传统的笔记管理让**人负责整理**（分类、标标签、建索引）。AI时代反转了：
- 人负责：**记录、思考、决策**
- AI负责：**整理、关联、检索、维护**

### 三层架构 (Karpathy Wiki 模型)

```
raw/       →   源材料（不可变·只增不改）
               你丢进来的原始素材：文章、笔记、截图、划线
               规则：绝不修改，source of truth

wiki/      →   结构化知识（AI维护）
               ├── concepts/ 概念页
               ├── entities/ 实体页
               └── topics/   主题页
               规则：AI写入+维护，人可修正

output/    →   查询产物（报告、分析）
               ⚡ 好output可以反哺wiki
```

**正向循环**：用户已有 `01-信息流/` ≈ raw/，各模块笔记 ≈ wiki/ 但缺统一SCHEMA。

### 三个关键文件

| 文件 | 作用 | 你的知识库对应 |
|------|------|--------------|
| **CLAUDE.md** | AI的员工手册：告诉AI你是谁、vault怎么组织、行为边界 | 你的 `00-六韬总纲.md` + `SOUL.md` 本质上就是这个角色 |
| **index.md** | 文件夹导航：每个文件夹放一个，AI 3秒知道里面有什么 | 你的总纲和中MOC就是在做这个 |
| **SCHEMA.md** | 规范宪法：统一命名/标签/链接规则 | 目前缺失——所有笔记的frontmatter格式不统一 |

### 格式化标准（待落地）

花叔推荐的frontmatter五字段，需要在你的知识库推广：

```yaml
---
title: 笔记标题
tags: [AI, knowledge-management]   # 英文标签
created: 2026-04-11                # ISO格式
type: permanent                    # fleeting(闪念) / literature(文献) / permanent(永久)
summary: 一句话摘要                 # 30-80字
---
```

### 七个可移植工作流

| # | 工作流 | 你做的事 | AI做的事 | 每日耗时 |
|:-:|--------|---------|---------|:-------:|
| 1 | 日记+AI周报 | 每天写几行 | 每周生成摘要 | 5分钟 |
| 2 | 读书笔记+提炼 | 读书划线批注 | 生成结构化笔记+建链接 | 读书时间 |
| 3 | 调研积累 | 存原始信息到raw/ | 编译成wiki+增量更新 | 调研时间 |
| 4 | 写作工作流 | 说一句选题 | 搜索vault+生成初稿 | 0 |
| 5 | 项目管理 | 建文件夹+写index | 跨项目链接知识 | 按需 |
| 6 | 自动整理旧笔记 | 把旧笔记丢进vault | 分类+加标签+建链接 | 一次性 |
| 7 | 自动Backlinks | 正常写笔记 | 自动识别实体+建链接 | 0 |

### 对用户当前知识库的诊断

**用户已做对的**：
- ✅ Vault在本地Markdown（AI可直接读写）
- ✅ 已经用 `01-信息流/` ≈ raw/ 做输入层
- ✅ 已有 `00-六韬总纲.md` 作为全局导航
- ✅ 已经用 `[[链接]]` 建立了跨模块关联
- ✅ 已经在用cron定时喂料
- ✅ 笔记数量适中（~101篇），完全不需要向量数据库

**可优化的**：
- ⚠️ 笔记frontmatter不统一——有的有tags/aliases/created，有的没有summary和type
- ⚠️ 缺乏SCHEMA.md定义统一的笔记规范
- ⚠️ 信息流笔记（`01-信息流/`下的.md）只是摘要，缺原文定位
- ⚠️ 缺index.md在每个文件夹（每个模块目录可以放一个）
- ⚠️ 可以建一个wiki/目录存放跨模块的"概念页"（如"致良知"、"次优选择"等）

---

## Part 2: Hermes Agent 操作指南

### 核心机制速查

```
学习循环：策划记忆 → 创建Skill → Skill自改进 → FTS5召回 → 用户建模
             ↕                                            ↕
         SQLite + FTS5                              Honcho (可选)

三层记忆：
  会话记忆（发生了什么） → 持久记忆（你是谁） → Skill记忆（怎么做事）
  SQLite+FTS5                                       ~/.hermes/skills/*.md
```

### 对用户环境的诊断

| 维度 | 当前状态 | 评估 |
|------|---------|------|
| 安装方式 | WSL2 local | ✅ 稳定 |
| Gateway | 飞书 websocket | ✅ 已通 |
| 记忆系统 | 三层自改进 | ✅ 自动运行 |
| Skill | 已装女娲+达尔文+花叔设计 | ✅ 但可手动优化 |
| 平台 | 飞书 | ⚠️ Hermes原生不支持飞书（但已通过Gateway bridge连通） |
| Cron | 1个每日喂料 | ✅ 已配 |
| MCP | 未配置 | ⚠️ 可接入GitHub等 |
| 迁移包 | 已放桌面 | ✅ |

### 何时提醒用户做什么

#### 日常维护提醒
- "清理过时Skill"：定期 `~/.hermes/skills/` 目录检查，删除不再用的
- "检查记忆增长"：`du -sh ~/.hermes/` 看看大小，过大的话清理
- "更新config"：换模型/provider时改 `config.yaml`

#### 进阶操作（用户有需求时启用）
- 接入GitHub MCP → 让Hermes自动审查你的GitHub通知
- 用delegate_task做并行调研 → 比如"同时调研三个方向"
- 用cron做定时推送 → 比如"每天8点发新闻摘要到飞书"
- 自定义Skill → 手动写 "git-commit-style.md" 等
- 装社区Skill → `hermes skill install [name]`

---

## Part 3: 迁移指南（简明版）

用户桌面已有 `C:\Users\18502\Desktop\Hermes迁移包\`，包含：

| 文件/目录 | 说明 |
|-----------|------|
| `config.yaml` | 飞书+模型配置 |
| `.env` | API密钥 |
| `memories/MEMORY.md + USER.md` | 我记住的一切 |
| `skills/` | 女娲+达尔文+花叔设计+自定义技能 |
| `cron/jobs.json` | 每日10点喂料 |
| `SOUL.md` | 定制人格 |
| `HermesGateway.vbs` | 开机自启脚本 |

**新电脑恢复步骤**：
1. 装WSL2+Ubuntu → `pip install hermes-agent`
2. 把 `~/.hermes/` 整个恢复
3. 连飞书：`hermes setup feishu`
4. 放VBS到启动文件夹
5. 装Obsidian+指向vault

---

## Part 4: 花叔的核心判断（可引用）

以下是可以直接引用影响用户决策的金句：

> **"过去几十年，知识工具都有一个共同假设：整理是你的事。AI改变的是这个假设。你可以只管往里扔东西，整理交给AI。你写，它织网。"**

> **"Karpathy的洞察：让AI把理解到的知识写成wiki文章——不是在检索，是在编译。检索器每次都在做重复劳动。编译器做一次工作，产出可复用的成果。"**

> **"Claude Code是工匠，Hermes是管家。工匠负责做东西，管家负责确保一切都在正轨上。"**

> **"最终胜出的不是某个工具，而是会组合工具的人。"**

> **"自改进Agent的天花板不在技术，在反馈信号。让Agent在'怎么做'上自改进，你只管'做什么'和'别做什么'。"**

> **"三万字以内，完全不需要向量数据库。Claude Code直接读Markdown文件就够了。"**
