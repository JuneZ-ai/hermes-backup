# Feishu Bitable (多维表格) API 操作指南

> 场景：通过飞书 Open API 创建/读写多维表格
> 凭证来源：`~/.hermes/.env` → `FEISHU_APP_ID` + `FEISHU_APP_SECRET`

## 鉴权

```python
import requests

resp = requests.post(
    "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
    json={"app_id": app_id, "app_secret": app_secret},
    timeout=10
)
token = resp.json()["tenant_access_token"]  # 有效期 2小时
headers = {"Authorization": f"Bearer {token}"}
```

## 已验证的 API 端点

### 创建多维表格（获取 app_token）

```python
POST /open-apis/bitable/v1/apps
{"name": "表格名称"}

# 返回:
{
  "code": 0,
  "data": {
    "app": {
      "app_token": "Cuq4bbKjsalf9DsMYZbcSz7gnkd",
      "default_table_id": "tblk8yltq9gjUjTH",
      "url": "https://my.feishu.cn/base/{app_token}"
    }
  }
}
```

**注意：没有"列出所有表格"的 API 端点**。你需要先知道 app_token 才能操作表格。要么主动创建，要么从飞书文档 URL 中提取。

### 在一个 Base 中创建第二个数据表

```python
# 最简：仅名称，会创建只有索引字段的空表
POST /open-apis/bitable/v1/apps/{app_token}/tables
{"table": {"name": "新表名称"}}

# 带字段和默认视图 — 注意：default_view_name 和 fields 必须同时提供或同时省略
POST /open-apis/bitable/v1/apps/{app_token}/tables
{
  "table": {
    "name": "每日记录",
    "default_view_name": "日历视图",
    "fields": [
      {"field_name": "公历时间", "type": 5, "ui_type": "DateTime",
       "property": {"date_formatter": "yyyy/MM/dd", "auto_fill": false}},
      {"field_name": "标题", "type": 1, "ui_type": "Text"}
    ]
  }
}
```

**关键规则：** `default_view_name` 和 `fields` 是**绑定的**——提供一个就必须提供另一个。同时省略则创建空表。

**DateTime 可以作为主字段（索引字段，type=5）**，支持的主字段类型：1(文本)、2(数字)、5(日期)、13(电话号码)、15(超链接)、20(公式)、22(地理位置)。

### 重命名数据表（PATCH，非PUT！）

```python
PATCH /open-apis/bitable/v1/apps/{app_token}/tables/{table_id}
{"name": "新名称"}
```

**关键坑：** 使用 **PATCH** 方法，不是 PUT。PUT 返回 404。不支持同时重命名多个属性。

### 列出字段

```python
GET /open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/fields
```

返回默认字段结构。新建表格的默认字段：

| field_name | type | type_id | 说明 |
|-----------|------|---------|------|
| 文本 | 1 (Text) | fld... | 主字段 (is_primary=true) |
| 单选 | 3 (SingleSelect) | fld... | 空选项列表 |
| 日期 | 5 (DateTime) | fld... | 格式 yyyy/MM/dd |
| 附件 | 17 (Attachment) | fld... | - |

### 字段管理

#### 重命名字段

```python
PUT /open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/fields/{field_id}
{
  "field_name": "新名称",
  "type": 1   # ⚠️ 必须传入 type，即使只是重命名！
}
```

**关键坑：** `type` 参数是**必需的**，即使只是改名称也必须传入。不传则返回 `code: 99992402` (`type is required`)。

#### 添加新字段

```python
POST /open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/fields
{
  "field_name": "状态",
  "type": 3,   # 1=Text, 3=SingleSelect, 5=DateTime, 17=Attachment
  "property": {
    "options": [
      {"name": "✅ 已完成", "color": 0},
      {"name": "⏳ 待跟进", "color": 1},
      {"name": "📋 计划中", "color": 2}
    ]
  }
}
```

#### 设置/更新字段选项（SingleSelect）

```python
PUT /open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/fields/{field_id}
{
  "field_name": "领域",   # 必须有
  "type": 3,              # 必须有
  "property": {
    "options": [
      {"name": "飞书权限开通", "color": 0},
      {"name": "API打通验证", "color": 1}
    ]
  }
}
```

**注意：** SingleSelect 的 `options` 通过 `property` 字段设置。`color` 取值为 0-7（飞书内置色号）。添加新字段用 POST，更新已有字段用 PUT。

### 写入记录

```python
POST /open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records
{
  "fields": {
    "文本": "内容",
    "日期": 1779361333000  # ⚠️ 毫秒级时间戳（epoch * 1000），不是秒！
  }
}
```

**关键坑 #1：** 字段名必须**完全匹配**已有字段名。不存在字段时返回 `code: 1254045` (`FieldNameNotFound`)。

**关键坑 #2（❌ 已踩过）：** DateTime 类型字段接收的是 **毫秒级** 时间戳（epoch 秒数 × 1000），不是秒。传入秒级时间戳会显示为 **1970 年**。

| 错误用法 | 正确用法 | 结果 |
|---------|---------|------|
| `1779361333`（秒） | `1779361333000`（毫秒） | ✅ 显示正确日期 |
| `int(time.time())`（秒） | `int(time.time()) * 1000`（毫秒） | ✅ 显示正确日期 |

### 删除记录

```python
DELETE /open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records/{record_id}
```

**适用场景：** 新建表格时默认模板会生成 10 条空记录，需要清理。识别空记录的依据是 `fields` 字典为空（`{}`）。

### 读取记录

```python
GET /open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records?page_size=10
```

返回 `items` 数组，每项包含 `record_id` 和 `fields` 字典。

### 列出云盘文件

```python
GET /open-apis/drive/v1/files?page_size=5
```

## 权限模型

飞书 Open API 有两种权限身份：

| 类型 | 说明 | 典型场景 |
|------|------|---------|
| **应用身份** (tenant_access_token) | 机器人自主操作 | 数据写入、自动化流程 |
| **用户身份** (user_access_token) | 模拟用户操作 | 需要用户上下文的操作 |

Bitable 读写用**应用身份**即可，不需要用户身份。

## 常见错误

| code | msg | 原因 |
|------|-----|------|
| 0 | success | 正常 |
| 1254045 | FieldNameNotFound | 写入的字段名不存在于表格中 |
| 99992402 | type is required | 更新字段时必须传 `type` 参数 |
| 99992402 | field validation failed | 参数校验失败，检查请求体各字段 |
| 99991672 | Access denied | 未开通对应权限（后台→权限管理→勾选后→**发布版本**） |

## 权限开通流程（已验证的四阶段扩展法）

**推荐顺序：** 一次只开一两个权限，**测试通过后再开下一批**，避免一次开太多不知道哪个出问题。

| 阶段 | 权限 | 测试方法 |
|------|------|---------|
| 1️⃣ 基础 | `im:message`（收发消息） | 安装即验证 |
| 2️⃣ 多维表格 | `bitable:app:*` | 建表→写记录→读记录 |
| 3️⃣ 日历 | `calendar:calendar:readonly` + `calendar:calendar` | 列日程→创建日程→删除日程 |
| 4️⃣ 任务+云文档 | `task:task:*` + `drive:drive:*` | 列任务→列文件 |

**操作步骤：**
1. 开发者后台 → **权限管理** → 找到对应分类 → 勾选所需权限
2. 左侧 → **版本管理与发布** → 创建版本 → 发布
3. 等待 1-2 分钟生效，然后测试

**最小权限原则：** 用多少开多少。先只开通当前阶段要测的权限，测试通过后再逐步扩展。

## 模板设计模式（已验证的多表架构）

在同一个 Base 中设计多个数据表，每个表有独立的用途和字段结构。以下模式已在本会话中验证通过。

### 模式1：搭建日志（系统追踪）

追踪系统搭建/配置过程的每一步操作。

| 字段 | 类型 | 说明 |
|------|------|------|
| ⭐ 操作内容 | Text (type=1) | 主字段，描述做了什么 |
| 领域 | SingleSelect (type=3) | 选项：飞书权限开通 / API打通验证 / 知识库基建 / 架构决策 / 工具配置 |
| 时间 | DateTime (type=5) | 操作时间（毫秒时间戳） |
| 状态 | SingleSelect (type=3) | ✅ 已完成 / ⏳ 待跟进 / 📋 计划中 |
| 备注 | Text (type=1) | 补充说明 |
| 附件 | Attachment (type=17) | 预留的文件附件 |

### 模式2：每日记录（带传统文化历法）

以**公历日期为第一列（主字段）**，附农历、节气、黄历。

> **用户偏好：** 表哥（表格）第一列必须是公历时间

| 字段 | 类型 | 说明 |
|------|------|------|
| ⭐ **公历时间** | **DateTime (type=5, primary)** | **第一列，主字段** |
| 农历 | Text | 从 `lunar-python` 计算 |
| 节气 | Text | 当前节气（如"小满"） |
| 干支 | Text | 年柱+月柱+日柱 |
| 黄历宜忌 | Text | 宜/忌/冲/煞 拼接 |
| 记录内容 | Text | 今天做了什么 |
| 类型 | SingleSelect | 读书/工作/会议/思考/生活/见闻 |

**关键设计决策：** DateTime 可以作为主字段（索引字段）。新建时在 `fields` 数组中第一个 field 设 `"type": 5` 即可。支持的主字段类型：1(文本)、2(数字)、5(日期)、13(电话号码)、15(超链接)、20(公式)、22(地理位置)。

**默认视图：** 建议设为日历视图（`"default_view_name": "日历视图"`），便于按日期浏览。

### 模式3：收藏随想录（书评/影评/新闻/随笔/歌曲）

通用收藏+笔记模板，适合随手收藏文章、写书评影评、记录新闻感想、记歌曲。

| 字段 | 类型 | 说明 |
|------|------|------|
| ⭐ **标题** | **Text (type=1, primary)** | 文章/书/电影名/歌名 |
| 来源链接 | Text | 原文/来源的 URL |
| 我的感悟 | Text | 个人思考（可空——纯收藏不写感悟也OK） |
| 金句摘录 | Text | 精彩的原文片段 |
| 来源类型 | SingleSelect | 📱 微信文章 / 🌐 网页 / 📚 书籍 / 🎧 播客 / 🎬 影视 / 📰 新闻 / 🎵 歌曲 / 📨 邮件/通讯 / 💬 聊天记录 / 📄 PDF/文档 / 其他 |
| 分类 | SingleSelect | 💻 技术/AI / 🏢 商业/管理 / 🧘 个人成长 / 🎯 认知/思维 / 📖 人文/社科 / 🔮 传统文化 / 📰 资讯/见闻 / 🎨 兴趣爱好 / 其他 |
| 收藏日期 | DateTime | 自动填写当天（`auto_fill: true`） |
| 评分 | SingleSelect | ⭐ 到 ⭐⭐⭐⭐⭐ |
| 状态 | SingleSelect | 🔖 已收藏 / 📖 在读 / ✅ 已读完 / 🔄 待重温 |

**使用方式：**
- **随手收藏** → 只填标题+链接+来源类型，感悟留空
- **深度记录** → 再加感悟+金句+评分
- **原创感悟** → 标题写感悟核心，来源类型选💬 聊天记录
- **状态流转** → 读完/看完后从"已收藏"改为"已读完"或"待重温"

### 模板设计原则

1. **主字段（第一列）选择**
   - 日期为中心的记录 → DateTime 作为主字段
   - 内容为中心的记录 → Text 作为主字段
   - 用户明确偏好时跟随用户偏好（如"第一列就是公历时间"）

2. **SingleSelect 选项命名**
   - 加 Emoji 前缀提升可读性（✅ ⏳ 📋 / 📱 🌐 📚 / 💻 🏢 🧘）
   - 11个来源类型选项已验证支持

3. **多个表共享一个 Base**
   - 同一个 Base 最多 100 个数据表
   - 关联字段（双向关联 type=21）可在表之间建立关联
   - 推荐按功能域分表（搭建日志 vs 每日记录 vs 收藏随想录）

4. **默认空记录的清理**
   - 新建表格时默认生成约 10 条空记录
   - 识别条件：`record["fields"] == {}`
   - 用 DELETE 逐条删除

## 经验总结

1. 没有"列出所有表格"的 API，需要用户提供 app_token（可从 URL 提取）
2. 建表时默认字段结构固定（文本/单选/日期/附件），建议先删除默认字段再建自己想要的
3. 字段名必须精确匹配，包括大小写和汉字
4. 获取 token → 建表 → 写记录 → 读记录，完整流程已验证可用
5. PATCH 重命名数据表，PUT 更新字段——方法弄混会返回 404
6. SingleSelect 的 options 更新需整个 property 替换（不支持增量添加）
7. 同一 Base 支持多表，建新表时 `default_view_name` 和 `fields` 必须同时提供或同时省略
