# Feishu Troubleshooting Reference

Common Feishu Open API error codes and their fixes for the Hermes Agent gateway.

## WebSocket 频繁断联 — No Ping/Keepalive

**Meaning:** The Feishu WebSocket connection drops frequently, especially after
laptop sleep/hibernation (S4 state), and doesn't auto-reconnect promptly.

**Root cause:** The Feishu adapter defaults `ws_ping_interval` to `None` —
no Ping/Pong frames are sent on the WebSocket. With no keepalive:

1. When the laptop hibernates (S4), the WSL network stack goes down
2. The TCP connection becomes half-open — neither side knows it's dead
3. The gateway never detects the disconnection until it tries to send a message
4. Without outgoing messages, the gateway sits in "connected" limbo indefinitely

**Diagnosis:**

Check for recent hibernation events in kernel logs:
```bash
journalctl -k --no-pager | grep "RTC can wake from S4" | tail -5
```

Check the current gateway's ping settings (look for the startup log or config):
```bash
systemctl --user status hermes-gateway --no-pager | head -5
grep "ws_ping_interval" ~/.hermes/config.yaml
```

If `ws_ping_interval` is absent or `null`, this is the problem.

**Fix — Enable WebSocket Ping Keepalive:**

Add an `extra` block under `platforms.feishu` in `~/.hermes/config.yaml`:

```yaml
platforms:
  feishu:
    enabled: true
    extra:
      ws_ping_interval: 25       # Send a ping every 25 seconds
      ws_ping_timeout: 10        # Wait 10s for pong; fail if none arrives
```

These values are read from `extra.get("ws_ping_interval")` in
`gateway/platforms/feishu.py` (line 1561) and applied to the lark-oapi
SDK's WebSocket client via the `_apply_runtime_ws_overrides()` monkey-patch
(lines 1294-1307).

The config.yaml `extra` dict is deep-merged with the env-var-sourced extra
dict (app_id, app_secret, domain, connection_mode) — both sources coexist.

**Verification:**

```bash
# Restart gateway for config to take effect
kill -9 $(systemctl --user show -p MainPID hermes-gateway --no-pager | cut -d= -f2)
sleep 3

# Confirm it reconnected
systemctl --user status hermes-gateway --no-pager | grep active
grep "connected to wss" <(journalctl --user -u hermes-gateway -n 5 --no-pager 2>&1)
```

After fix: the gateway sends a WebSocket PING every 25s. If the connection
goes stale (e.g., laptop sleeps), the PONG times out after 10s, the lark-oapi
SDK fires an error, the gateway detects the platform is disconnected, and
the `_platform_reconnect_watcher` (runs every 10s) reconnects automatically.

Maximum detection time after resume: 25s (ping interval) + 10s (timeout) = ~35s.

**How the code works:**

The Feishu adapter defines default values at class scope (line 387-390):
```python
ws_reconnect_nonce: int = 30
ws_reconnect_interval: int = 120
ws_ping_interval: Optional[int] = None        # < disabled by default
ws_ping_timeout: Optional[int] = None
```

When building settings (line 1561-1562), it reads from `extra`:
```python
ws_ping_interval=_coerce_int(extra.get("ws_ping_interval"), default=None, min_value=1),
ws_ping_timeout=_coerce_int(extra.get("ws_ping_timeout"), default=None, min_value=1),
```

The values are applied at runtime (lines 1298-1307):
```python
setattr(ws_client, "_ping_interval", adapter._ws_ping_interval)
# and
kwargs["ping_interval"] = adapter._ws_ping_interval
```

The built-in auto-reconnect of the lark-oapi WS client is explicitly disabled
after initial connection (`_disable_websocket_auto_reconnect`), and the
gateway's own `_platform_reconnect_watcher` handles reconnection instead.

---

## Error 200340 — app_ticket Invalid

**Meaning:** The lark_oapi SDK's WebSocket connection ticket (app_ticket) has expired or
is invalid. This is the authentication credential the SDK uses behind the scenes for
API calls (sending messages, uploading media, etc.).

**When it happens:**
- After multiple rapid Gateway restarts — the old ticket is stale but the SDK hasn't
  obtained a fresh one
- The Gateway process was stuck in `deactivating (stop-sigterm)` and never completed
  a clean WebSocket close + reconnect cycle
- The app_secret was changed on the Feishu Open Platform but the `.env` file still
  has the old value (also prevents WebSocket connection entirely)
- **Interactive Card buttons clicked without Card Request URL configured** — clicking
  Allow Once / Session / Always / Deny on command approval cards returns 200340

**Symptoms:**
- Feishu client shows a system error with code 200340 after sending a message to the bot
- Bot appears online but replies never arrive
- Clicking approval card buttons returns 200340

**Diagnosis:**

Check the agent log for WebSocket connection details:

```bash
grep "Lark: connected to wss" ~/.hermes/logs/agent.log | tail -5
```

Each line shows:
```
... INFO Lark: connected to wss://msg-frontier.feishu.cn/ws/v2?...
  ...&access_key=...&ticket=<uuid>... [conn_id=...]
```

Look for:
- A `ticket=` UUID — this is the current app_ticket
- The most recent connection timestamp — if it's older than the last Gateway start,
  the ticket may be stale

Also check if the Feishu adapter is actually connected:

```bash
grep "feishu connected" ~/.hermes/logs/gateway.log | tail -3
```

**Fix option 1 (app_ticket expired) — Force restart Gateway:**

```bash
# Find the PID
systemctl --user status hermes-gateway --no-pager | grep 'Main PID'

# Force kill (replace PID)
kill -9 <pid>

# Wait for systemd to auto-restart (2-3 seconds)
sleep 3

# Verify
systemctl --user status hermes-gateway --no-pager | head -5

# Check new connection with fresh ticket
sleep 10 && grep "Lark: connected" ~/.hermes/logs/agent.log | tail -1
```

The new connection will have a different `ticket=` UUID and a new `conn_id=`.

**Fix option 2 (Interactive Card buttons) — Configure Feishu Developer Console:**
1. Subscribe to `card.action.trigger` event in Event Subscriptions
2. Enable "Interactive Card" capability toggle in App Features > Bot
3. Configure Card Request URL (auto-handled in WebSocket mode)

**Fix option 3 (Simple workaround) — Disable command approvals entirely:**
```bash
hermes config set approvals.mode off
```
This bypasses the need for Interactive Cards entirely — commands execute without
approval prompts. Best for users who find the Feishu Developer Console configuration
too complex. No Gateway restart needed, takes effect immediately.

**Prevention:**
- Avoid restarting Gateway rapidly — let each shutdown complete fully
- If Gateway is stuck in `deactivating (stop-sigterm)`, always use `kill -9` then
  let systemd auto-restart (don't issue another `systemctl restart`)
- For users who don't want to configure Interactive Cards: just set `approvals.mode off`

---

## Permission Diagnosis — 飞书授权检查方法

**场景：** 确认 bot 的权限是否过多或不足。多开权限有安全风险，少开权限会导致 API 调用失败。

**分析方法：** 检查 Feishu 网关平台代码中实际调用的 HTTP API 端点，反向推导所需 scope。

```bash
# 1. 找到代码中调用的 Feishu Open API 端点
grep -E "\.uri\(|\.v1\.\w+\.(create|get|update|delete|reply)" \
  /usr/local/lib/hermes-agent/gateway/platforms/feishu.py | head -30
```

**常见 API → Scope 映射表：**

| API 调用 | 所需 Scope | 必要性 |
|----------|-----------|--------|
| `im.v1.message.create` / `.reply` / `.get` / `.update` | `im:message` | ✅ 必需 |
| `im.v1.image.create` / `im.v1.message_resource.get` | `im:resource` | ✅ 必需 |
| `im.v1.chat.get` | `im:chat` | ⚠️ 推荐 |
| `im.v1.message_reaction.create` / `.delete` | `im:message.reaction` | ⚠️ 推荐（打字/完成标记） |
| `bot/v3/info` | 无（使用 tenant_access_token 即可） | 内置 |
| `drive/*` / `docx/*` / `contact/*` | 不需要（代码未调用） | ❌ 不开 |

**操作步骤：**

```bash
# 2. 查看当前 .env 中的 App ID
grep FEISHU_APP_ID ~/.hermes/.env

# 3. 在飞书开放平台 (open.feishu.cn) → 应用 → 权限管理
#    按上述表格核对已授权的 scope 列表
#    去掉不需要的 scope（drive、docx、contact 等）
#    发布新版本使权限变更生效
```

**常见问题：**
- 开了 `im:message` 但没开 `im:chat` → `chat.get` 调用返回 230011 或类似错误
- 误开了 `drive:drive` → 虽然不影响功能，但授权过多，建议移除
- 显示 `im:message:send_as_bot` 不是有效的飞书 scope 名，`im:message` 已覆盖

---

## Other Common Errors

### Error 230011 — Message Not Found

The reply target message (the user's message you're replying to) was deleted or
is no longer accessible. The adapter auto-falls back to creating a new message
instead of replying.

No action needed — this is handled internally.

### Error 231003 — Chat ID Invalid

Similar to 230011 — the target chat context expired. Also handled by the
adapter's reply-fallback mechanism.

### Error 10001 — Invalid Auth

The `tenant_access_token` used for the API call is malformed or expired.
Typically transient — the SDK auto-refreshes. If persistent, check that
`FEISHU_APP_SECRET` in `.env` matches the 飞书开放平台 credential page.

---

## Quick Diagnostic Commands

```bash
# Recent connection activity
grep -E "feishu.*connect|Lark: connected" ~/.hermes/logs/agent.log | tail -5

# Any Feishu-related errors in the last 100 lines
grep -i "feishu.*error" ~/.hermes/logs/gateway.log | tail -10

# Message flow — are messages being received and sent?
grep -E "Inbound dm|Sending response" ~/.hermes/logs/gateway.log | tail -10

# Gateway process health
systemctl --user status hermes-gateway --no-pager

# Check for laptop hibernation events (S4 sleep)
journalctl -k --no-pager | grep "RTC can wake from S4" | tail -5

# Verify WebSocket keepalive is configured
grep "ws_ping_interval" ~/.hermes/config.yaml
```
