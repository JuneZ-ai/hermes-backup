# 腾讯云 TokenHub Provider Setup

TokenHub（令牌服务）是腾讯云提供的模型网关服务，通过 OpenAI 兼容的 API 提供多种模型（DeepSeek、混元、GLM 等）的调用能力。

## API 地址

```
https://api.tokenhub.cloud.tencent.com/v1
```

## 认证方式

TokenHub 的 OpenAI 兼容 API **不支持**直接使用腾讯云 SecretId/SecretKey 认证。需要先在 TokenHub 控制台创建一个 **API Key（令牌）**，然后通过 Bearer Token 方式传入：

```
Authorization: Bearer <your-api-key>
```

### 配置方式

在 Hermes 的 `config.yaml` 中：

```yaml
model:
  default: <model-name>
  provider: custom
  base_url: https://api.tokenhub.cloud.tencent.com/v1
  api_key: <your-tokenhub-api-key>
```

或者通过 CLI 命令：

```bash
hermes config set model.default <model-name>
hermes config set model.provider custom
hermes config set model.base_url https://api.tokenhub.cloud.tencent.com/v1
hermes config set model.api_key <your-tokenhub-api-key>
```

### 创建 API Key 步骤

1. 打开 https://console.cloud.tencent.com/tokenhub
2. 使用 SecretId/SecretKey 登录
3. 在控制台找到"创建令牌/API Key"的入口
4. 生成一个 API Key
5. 将生成的 Key 复制出来用于配置

### 可用模型

TokenHub 支持多种模型，具体列表可通过以下方式获取：

```bash
curl -H "Authorization: Bearer <your-api-key>" \
  https://api.tokenhub.cloud.tencent.com/v1/models
```

常见模型名格式：`deepseek-v3`、`deepseek-r1`、`glm-4-plus`、`hunyuan-turbo` 等，以实际查询结果为准。

## 切换到 TokenHub 后的注意事项

- 修改配置后，Gateway 需要重启（在飞书发 `/restart`）才能生效
- 如果 TokenHub 模型支持 vision，则 `vision_analyze` 工具可以使用
- TokenHub 的响应延迟取决于所选模型，与 DeepSeek 直连可能不同
