#!/usr/bin/env python3
"""Survey Obsidian vault: files, frontmatter, field coverage, empty files."""
import os, re, yaml
from pathlib import Path

VAULT = "/mnt/c/Users/18502/Documents/Obsidian Vault"

files = []
for root, dirs, fnames in os.walk(VAULT):
    for fn in fnames:
        if not fn.endswith(".md"):
            continue
        fp = Path(root) / fn
        rel = str(fp.relative_to(VAULT))
        sz = fp.stat().st_size
        content = fp.read_text(encoding='utf-8', errors='ignore')
        
        fm_fields = []
        if content.startswith('---'):
            m = re.search(r'^---\s*\n(.*?)\n(---)', content, re.DOTALL)
            if m:
                try:
                    fm = yaml.safe_load(m.group(1))
                    if isinstance(fm, dict):
                        fm_fields = list(fm.keys())
                except:
                    pass
        files.append((rel, sz, fm_fields, len(content)))

print(f"Total files: {len(files)}\n")

# Field coverage
field_counts = {}
for rel, sz, fields, clen in files:
    for f in fields:
        field_counts[f] = field_counts.get(f, 0) + 1

print("=== Field presence ===")
for f, c in sorted(field_counts.items(), key=lambda x: -x[1]):
    print(f"  {f}: {c}/{len(files)} ({c*100//len(files)}%)")

print()
print("=== Files WITHOUT frontmatter ===")
for rel, sz, fields, clen in files:
    if not fields:
        print(f"  {rel} ({sz}b)")

print()
print("=== Empty files (might show as 'unnamed') ===")
for rel, sz, fields, clen in files:
    if clen < 50:
        print(f"  {rel} ({sz}b)")

print()
print("=== Files missing 'tags' ===")
for rel, sz, fields, clen in files:
    if fields and 'tags' not in fields:
        print(f"  {rel}  fields={fields[:5]}")

print()
print("=== Files missing 'aliases' ===")
for rel, sz, fields, clen in files:
    if fields and 'aliases' not in fields:
        print(f"  {rel}")

print()
print("=== Directory structure ===")
dirs = set()
for rel, sz, fields, clen in files:
    d = os.path.dirname(rel)
    if d: dirs.add(d)
for d in sorted(dirs):
    count = len([f for f in files if f[0].startswith(d + '/')])
    print(f"  {d}/  ({count} files)")
