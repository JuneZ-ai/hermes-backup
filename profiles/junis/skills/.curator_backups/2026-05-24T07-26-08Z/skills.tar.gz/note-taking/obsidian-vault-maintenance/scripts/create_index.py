#!/usr/bin/env python3
"""Create index.md in every module directory with proper navigation links."""
import os

VAULT = "/mnt/c/Users/18502/Documents/Obsidian Vault"

def get_md_files(dirpath, max_depth=1):
    result = {}
    for root, dirs, fnames in os.walk(dirpath):
        depth = root.replace(dirpath, '').count(os.sep)
        if depth >= max_depth:
            dirs[:] = []
            continue
        for f in sorted(fnames):
            if f.endswith('.md') and f != 'index.md':
                rel = os.path.relpath(os.path.join(root, f), dirpath)
                title = f.replace('.md', '')
                result[rel] = title
    return result

def write_index(dirname, title, desc, sections=None):
    target = os.path.join(VAULT, dirname)
    if not os.path.isdir(target):
        return
    
    lines = [
        "---",
        f"title: {title}",
        f"tags: [index, navigation]",
        f"created: 2026-05-21",
        f"---",
        "",
        f"# {title}",
        "",
    ]
    if desc:
        lines.append(f"> {desc}")
        lines.append("")
    lines.append("---")
    lines.append("")
    
    total = 0
    if sections:
        for name, sec_desc, subpath in sections:
            lines.append(f"## 📂 {name}")
            if sec_desc:
                lines.append(f"> {sec_desc}")
                lines.append("")
            subdir = os.path.join(VAULT, dirname, subpath)
            if os.path.isdir(subdir):
                sub_files = get_md_files(subdir, max_depth=0)
                for rel, t in sorted(sub_files.items()):
                    lines.append(f"- [[{subpath}/{t}|{t}]]")
                    total += 1
            lines.append("")
            lines.append("---")
            lines.append("")
    
    direct = {k: v for k, v in get_md_files(target, max_depth=0).items() if '/' not in k}
    if direct:
        for rel, t in sorted(direct.items()):
            lines.append(f"- [[{t}|{t}]]")
            total += 1
        lines.append("")
        lines.append("---")
        lines.append("")
    
    lines.append(f"*📊 共 {total} 篇笔记*")
    
    idx_path = os.path.join(target, 'index.md')
    with open(idx_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))
    print(f"Created: {dirname}/index.md ({total} entries)")
