---
name: obsidian-vault-maintenance
description: "Use when auditing, standardizing, or upgrading an Obsidian vault. Covers frontmatter unification, index.md navigation generation, wiki/ cross-module concept pages, and knowledge base health checks."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [obsidian, vault, note-taking, knowledge-base, maintenance]
    related_skills: [knowledge-synthesis, textual-alchemist-hermes]
---

# Obsidian Vault Maintenance

> 知识库不是写完就算的——需要定期体检、升级、统一。

## When to Use

- 发现 vault 中 frontmatter 格式不统一（有的有 tags/aliases，有的没有）
- 需要创建 index.md 导航文件让每个模块可快速浏览
- 需要创建 wiki/ 跨模块概念页
- 收到用户"优化 vault"的指令
- 发现重复/空文件需要清理
- 需要审计 vault 健康状况（文件数、字段覆盖、孤立页面）

## 工作流

### 1. 全面审计

第一步：摸底 vault 的状态。

```bash
python3 survey_vault.py
```

脚本应统计：
- 文件总数
- 各 frontmatter 字段覆盖率（title/tags/aliases/created/updated/cssclasses）
- 无 frontmatter 的文件
- 缺少 tags 的文件
- 缺少 aliases 的文件
- 目录结构（各模块文件数）

### 2. Frontmatter 统一

写一个 Python 修复脚本，规则：

| 操作 | 条件 | 值 |
|------|------|-----|
| 补充 `tags` | 文件中没有 tags | 从所在目录推断（`六韬智脑`→ `[六韬智脑]`, `01-信息流`→ `[info-feed, source-material]`） |
| 补充 `aliases` | 没有 aliases | 从 title 自动生成（去除编号前缀和括号内容） |
| 修复 `cssclass`→`cssclasses` | 存在 `cssclass:` 字段 | 改为 `cssclasses:` |
| 补充 `created` | 没有 created | 当前日期 |
| 补充 `updated` | 没有 updated | 当前日期 |

**关键**：只追加缺失字段，不重写整个 frontmatter（避免破坏现有格式）。使用 Python 逐行处理，yaml解析仅用于检测字段缺失，追加操作用纯文本。

用户偏好的 tag 风格：
- 列表格式：`tags: [tag1, tag2]` 或 YAML block `tags:\n  - tag1\n  - tag2`
- 先检查现有格式，保持一致

### 3. 目录推断映射

```python
DIR_TAGS = {
    "01-信息流": "info-feed, source-material",
    "六韬易哲": "六韬易哲",
    "六韬易哲/中医基础": "六韬易哲, 中医",
    "六韬易哲/八字命理": "六韬易哲, 八字",
    "六韬易哲/易经体系": "六韬易哲, 易经",
    "六韬易哲/相学体系": "六韬易哲, 相学",
    "六韬智脑": "六韬智脑",
    "六韬道史": "六韬道史",
    "决断之桥": "决断之桥",
    "太极双螺旋": "太极双螺旋",
    "实战案例": "实战案例",
}
```

匹配按目录深度降序排列（更深目录优先匹配）。

### 4. 创建 index.md

每个模块目录需要一个 `index.md`，包含：

```markdown
---
title: <模块名>
tags: [index, navigation]
created: YYYY-MM-DD
---

# <模块名> · <描述>

> 一句话定位

## 📂 子模块（如有）
- [[子模块/笔记名|显示名]] — 一句话用途

## 条目列表（直接文件）
- [[笔记名]]
- [[笔记名]]

---

*📊 共 N 篇笔记*
```

规则：
- **根目录 index**：列出所有模块的快捷入口
- **模块 index**：列出该模块下所有直接文件 + 子模块目录
- **子模块 index**（可选）：如果子模块文件 > 5，也创建 index

链接使用 Obsidian 的 `[[wiki/语法]]` 格式，**不**需要文件名去 `.md` 后缀。

### 5. 创建 wiki/ 概念页

跨模块的概念需要独立的 wiki 条目，格式：

```markdown
---
title: 概念名
tags: [wiki, cross-module]
aliases: [别名]
created: YYYY-MM-DD
---

# 概念名

> 一句话定义

## 概念来源
- [[相关笔记1]]
- [[相关笔记2]]

## 核心逻辑
（2-3句话）

## 跨模块关联
| 模块 | 关联点 |
|------|--------|
| 六韬智脑 | ... |

## 实战意义
（1-2句）
```

哪些概念需要 wiki：
- 跨两个以上模块的概念（如「人机协作」涉及 六韬智脑/AI框架 + 六韬道史/道）
- 核心术语需要统一解释（如「上下文税」「预算内生化」「调度折价」）
- 哲学/方法论概念（「物我合一」「灰度」）

### 6. 清理空文件

空文件在 Obsidian 中显示为「未命名」，必须删除。检查规则：

```bash
# 查找小文件（< 50字节，排除纯frontmatter）
find "$VAULT" -name "*.md" -size -50c
```

也检查重复条目：同名或同内容的不同位置文件。保留最完整的版本，其他改为简短链接页。

## 用户特定规则

- 用户期望你**主动**做 vault 体检升级，不需要提醒
- frontmatter 统一必须在写入前测试单文件（避免批量破坏）
- z 中文文件名和内容，确保 UTF-8 编码
- 所有 `.md` 文件按模块编号排序（00-总览 → 01-xxx → 02-xxx ...）
- 知识库条目的 cssclasses 统一用 `"deep-dive"`（六韬智脑条目）或 `"quick-ref"`（速查版）

## Pitfalls

1. **yaml.dump 会重排字段顺序** — 不要用 dump 重写整个 frontmatter，只追加缺失行。
2. **`---\n---` 空 frontmatter** — 有些编辑器会产生空 frontmatter，检查并跳过或删除。
3. **Obsidian 不显示更新** — 改动后需要手动 Ctrl+R 刷新，或重启 Obsidian。
4. **Windows 换行符** — WSL 写的文件在 Obsidian 中正常，无需转换。
5. **文件名中的特殊字符** — Obsidian 支持 Unicode 文件名（包括 `·`、冒号等），但 `[]` `#` `|` 会导致解析问题。
6. **`cssclass` vs `cssclasses`** — 正确字段是 `cssclasses`（带 s）。4 个文件曾误用了 `cssclass`。
7. **wiki 页面必须双向链接** — 概念页必须引用回源笔记，否则 Obsidian 图谱中显示为孤立节点。

### 7. 总纲树形图更新

添加新条目到 `00-六韬总纲.md` 的 ASCII 树形图时，必须同步做三件事：

**a. 树形图语法**
```
│   ├── [[六韬智脑/09-人物志识人术\|人物志识人术]]   —— 五卷·九征
│   └── **[[六韬智脑/20-格局逆袭制胜之道\|格局逆袭·宗宁]]** —— 普通人的制胜之道 ← NEW
```
- `├──` = 非最后一个条目，`└──` = 最后一个条目
- **粗体** = Deep-Dive/深研版条目
- `\|` 转义管道符（在代码块内用单反斜杠，YAML 表格内用 `\\|`）

**b. 统计表更新** — 在 `## 📊 模块状态一览` 表中更新笔记数字

**c. 使用场景速查表** — 如需新增入口，在 `## 🎯 使用场景速查` 表添加一行

### 8. 健康检查：断链 + 孤岛 + 覆盖率审计

定期对 vault 执行三项检查：

**坏链检测**
```bash
grep -rohP '\[\[[^\]]+\]\]' --include="*.md" . | \
  sed 's/\[\[//' | sed 's/\]\]//' | sed 's/|.*//' | sort -u | while read link; do
    echo "$link" | grep -qE '^(http|www|#)' && continue
    clean=$(echo "$link" | sed 's|\.\./||g; s|\./||')
    [ -z "$(find . -path "*/$clean.md" 2>/dev/null | head -1)" ] && echo "BROKEN: [[$link]]"
  done
```

**孤岛笔记检测**
```bash
for f in $(find . -name "*.md" -not -path "./.obsidian/*"); do
  bn=$(basename "$f" .md)
  case "$bn" in "index"|"欢迎"|"00-六韬总纲") continue ;; esac
  [ "$(grep -rl "\[\[$bn" --include="*.md" . | grep -v "$f" | grep -v "./.obsidian" | wc -l)" -eq 0 ] && echo "ORPHAN: $f"
done
```

**跨模块引用覆盖率**
| 检查项 | 理想状态 | 可疑 |
|--------|---------|------|
| wiki/ 概念页入链 | 每个 ≥2 | 0-1 条 |
| _标准/ 文档入链 | ≥1（总纲或欢迎页）| 0 |
| 六韬易哲子模块 index.md | 5 个各 1 个 | 缺失 |
| MOC地图 入链 | 从总纲直达 | 仅子模块引用 |

### 9. 子模块 index.md 批量创建

当 5+ 个子模块缺 index.md，用并行 delegate_task：

```python
tasks = [
    {"goal": f"Create index.md for {subdir}", "toolsets": ["file"]},
    ...  # 最多 3 个并行
]
delegate_task(tasks=tasks)
```

统一格式：YAML frontmatter → 标题+引言 → [[wikilinks]] 列表 → 统计行。

## 验证清单

- [ ] 审计脚本成功运行，输出统计到标准输出
- [ ] frontmatter 修复先测试 1 个文件
- [ ] 批量修复后抽查 3-5 个文件确认格式正确
- [ ] index.md 在所有模块目录存在
- [ ] 每个 index.md 的链接可正常跳转（无 404）
- [ ] wiki/ 目录存在，每个概念页都含双向链接
- [ ] 无空文件残留
- [ ] Obsidian 刷新后正常显示

## 内置脚本

| 脚本 | 用途 | 位置 |
|------|------|------|
| `survey_vault.py` | 全面审计：文件数、字段覆盖率、空文件 | `scripts/survey_vault.py` |
| `fix_frontmatter.py` | 批量补全缺失的 tags/aliases/created/updated | `scripts/fix_frontmatter.py` |
| `create_index.py` | 为所有模块生成 index.md 导航 | `scripts/create_index.py` |

## Vault 参考

- `references/vault-architecture.md` — 完整目录结构、frontmatter 标准、编号规范、喂料流程
