#!/usr/bin/env python3
"""
Add missing frontmatter fields ONLY. Preserves all existing formatting.
Never uses yaml.dump to rewrite (would reorder fields).
"""
import os, re, yaml
from pathlib import Path

VAULT = "/mnt/c/Users/18502/Documents/Obsidian Vault"
TODAY = "2026-05-21"

DIR_TAGS = {
    "01-信息流": "info-feed, source-material",
    "六韬易哲/MOC地图": "六韬易哲, MOC",
    "六韬易哲/中医基础": "六韬易哲, 中医",
    "六韬易哲/倪海厦天纪/人间道": "六韬易哲, 倪海厦, 人间道",
    "六韬易哲/倪海厦天纪/地脉道": "六韬易哲, 倪海厦, 地脉道",
    "六韬易哲/倪海厦天纪/天机道": "六韬易哲, 倪海厦, 天机道",
    "六韬易哲/倪海厦天纪": "六韬易哲, 倪海厦",
    "六韬易哲/八字命理": "六韬易哲, 八字",
    "六韬易哲/易经体系": "六韬易哲, 易经",
    "六韬易哲/相学体系": "六韬易哲, 相学",
    "六韬易哲": "六韬易哲",
    "六韬智脑": "六韬智脑",
    "六韬道史": "六韬道史",
    "决断之桥/知识库": "决断之桥, 知识库",
    "决断之桥": "决断之桥",
    "太极双螺旋": "太极双螺旋",
    "实战案例": "实战案例",
    "MOC地图": "MOC",
}

stats = {"tags": 0, "aliases": 0, "cssclass": 0, "created": 0, "updated": 0}

for root, dirs, fnames in os.walk(VAULT):
    for fn in fnames:
        if not fn.endswith(".md"):
            continue
        fp = Path(root) / fn
        rel = str(fp.relative_to(VAULT))
        content = fp.read_text(encoding='utf-8', errors='ignore')
        
        if not content.startswith('---'):
            continue
        
        m = re.search(r'^---\s*\n(.*?)\n(---)', content, re.DOTALL)
        if not m:
            continue
        
        fm_text = m.group(1)
        try:
            fm = yaml.safe_load(fm_text)
            if not isinstance(fm, dict):
                continue
        except:
            continue
        
        lines = fm_text.split('\n')
        modified = False
        
        # Fix cssclass -> cssclasses
        new_lines = []
        for line in lines:
            if line.strip().startswith('cssclass:'):
                has_cssclasses = any(l.strip().startswith('cssclasses:') for l in lines)
                if not has_cssclasses:
                    new_lines.append(line.replace('cssclass:', 'cssclasses:'))
                    stats["cssclass"] += 1
                    modified = True
                    continue
                else:
                    continue
            new_lines.append(line)
        lines = new_lines
        
        # Add tags if missing
        if not any(l.strip().startswith('tags:') for l in lines):
            dirmatch = ""
            for d in sorted(DIR_TAGS.keys(), key=len, reverse=True):
                if str(rel).startswith(d):
                    dirmatch = DIR_TAGS[d]
                    break
            if dirmatch:
                lines.append(f"tags: [{dirmatch}]")
                stats["tags"] += 1
                modified = True
        
        # Add aliases if missing
        if not any(l.strip().startswith('aliases:') for l in lines):
            title = fm.get('title', '')
            if title:
                alias = re.sub(r'^\d+-?\s*', '', title)
                alias = re.sub(r'[（(].*?[）)]', '', alias).strip()
                if alias:
                    lines.append(f"aliases: [{alias}]")
                    stats["aliases"] += 1
                    modified = True
        
        if not any(l.strip().startswith('created:') for l in lines):
            lines.append(f"created: {TODAY}")
            stats["created"] += 1
            modified = True
        if not any(l.strip().startswith('updated:') for l in lines):
            lines.append(f"updated: {TODAY}")
            stats["updated"] += 1
            modified = True
        
        if modified:
            new_content = f"---\n{chr(10).join(lines)}\n---{content[m.end():]}"
            fp.write_text(new_content, encoding='utf-8')
            print(f"  UPDATED: {rel}")

print(f"\nTags added: {stats['tags']}, Aliases: {stats['aliases']}, cssclass: {stats['cssclass']}, created: {stats['created']}, updated: {stats['updated']}")
