---
name: wechat-content-publishing
description: |-
  Write and deliver WeChat public account articles for the user's brand (蛮不错).
  Covers the full workflow: draft → format → image prompts → publish checklist → file delivery.
  The user wants a frictionless "一键发送" experience — minimize the steps they need to take.
version: 1.0.0
author: Hermes Agent
license: MIT
tags: [content, publishing, wechat, social-media, series]
trigger_keywords: [公众号, 发文章, 写一篇, 蛮不错, 六韬, 发布]
---

# WeChat Content Publishing · 公众号文章发布工作流

## User Preferences (embed these in every article)

| Preference | Value |
|-----------|-------|
| **Account** | 蛮不错 (the user's only public account) |
| **Author name** | 六韬 |
| **Max length** | ≤800 Chinese characters (strict) |
| **Structure** | Series format — split long content into numbered posts |
| **Images** | Provide prompt text for cover/inline images; generate if FAL_KEY is available, otherwise give prompts for the user's own tool (MJ/DALL·E) |
| **Delivery** | Save files to a Windows-accessible path for easy copy-paste |
| **Tone** | Personal, practical, not salesy — "记录一下" not "卖课" |
| **Call to action** | Light: "转发给一个朋友就是最好的支持" |

## One-Click Publishing Workflow

### Step 1: Draft (my side)
1. Read relevant vault content
2. Write ≤800 Chinese character article
3. Include: hook in first paragraph, concrete example (cross-module analysis), series teaser
4. Sign off: "我是六韬，[一句话身份定位]。"

### Step 2: Package (my side)
Save to standardized path:
```
/mnt/c/Users/18502/WorkBuddy/Claw/公众号文章/
├── NN-标题.md                ← article body (copy-paste ready)
├── NN-配图提示词.txt          ← image generation prompts
└── NN-发布清单.md             ← publish checklist
```

**NN format**: 01, 02, 03... matching the series sequence.

### Step 3: Article Body Format (NN-标题.md)
```markdown
# 标题

> 引语（可选）

正文...

*我是六韬，[身份定位]。*
*觉得有用的话，转发给一个朋友就是最好的支持。*
```

### Step 4: Publish Checklist (NN-发布清单.md)
```
□ 标题：[标题]
□ 署名：六韬
□ 封面图：用提示词生 → 存本地 → 上传
□ 正文：已写好，直接复制
□ 赞赏：开/关
□ 原文链接：填/不填
□ 发布时间：[建议时间]
```

### Step 5: Image Prompts (NN-配图提示词.txt)
- Provide both Chinese description and English prompt
- 16:9 aspect ratio for cover
- Match article tone (philosophical tech for 第二大脑 series)

## Article Structure Template

```
Title: <hook-driven, under 20 chars>

Paragraph 1: Problem/context (the user's real situation)
Paragraph 2-3: What they did (the solution)
Paragraph 4-5: Concrete example (show, don't tell)
Paragraph 6: The realization/insight
Paragraph 7: What's next (series teaser)
Sign-off: Author + CTA
```

## Series Management

- Keep a running list of published articles in `/mnt/c/Users/18502/WorkBuddy/Claw/公众号文章/`
- Track which topics are covered to avoid repetition
- Each article should stand alone (new readers can start anywhere)
- Series teaser at the end of each article lists upcoming topics

## Pitfalls

1. **Overwriting the user's voice** — The user has their own style. Keep it personal, not corporate. Use their real experiences, not generic advice.
2. **Exceeding 800 chars** — This is a hard constraint. Count Chinese characters specifically (not total bytes).
3. **Forgetting images** — Every article needs at least one cover image prompt. Inline images for key visuals are a nice bonus.
4. **Not saving to the Windows path** — Save to `/mnt/c/Users/18502/...` not `/home/hermes/...` so the user can access files directly from Windows.
5. **Assuming I can publish directly** — I cannot log into WeChat backend. The workflow ends at file delivery.
