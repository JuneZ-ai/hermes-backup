---
name: knowledge-base-audit
description: Diagnose, analyze, and plan evolution for an Obsidian-based second brain / personal knowledge management (PKM) system. Covers structural exploration, quantitative metrics, qualitative assessment, bottleneck diagnosis, and tiered evolution planning.
triggers:
  - user asks to "analyze my knowledge base" / "how should my vault evolve" / "第二大脑还需要怎么进化" / "diagnose my second brain"
  - user asks for a "knowledge base health check" or "vault audit"
  - user says "how can I improve my note-taking system"
  - any session where the primary goal is understanding the state and trajectory of a PKM/Obsidian vault
platforms: [linux, macos, wsl]
---

# Knowledge Base Audit & Evolution Planning

A systematic method for auditing an Obsidian-based second brain, diagnosing bottlenecks, and proposing a tiered evolution plan.

---

## Phase 1: Structural Exploration

### 1.1 Get the vault path

The vault path is typically under the user's Documents directory. Common locations:

- `~/Documents/Obsidian Vault/` (Linux/macOS)
- `/mnt/c/Users/<username>/Documents/Obsidian Vault/` (WSL)
- `$OBSIDIAN_VAULT_PATH` (env var, check ~/.hermes/.env)

Use `search_files` or a quick `terminal` `ls` to verify the path exists.

### 1.2 Map the directory tree

```python
# In execute_code or terminal:
import subprocess
root = "/path/to/vault"
result = subprocess.run(["find", root, "-name", "*.md", "-not", "-path", "*/.obsidian/*"],
                        capture_output=True, text=True, timeout=30)
all_mds = [f for f in result.stdout.strip().split("\n") if f]
```

Key observations:
- **Top-level directories**: What's the organizing metaphor? (tree / building / library / zettelkasten / PARA / etc.)
- **File naming conventions**: Are there prefixes (ZN-, DS-, LX-, etc.)? Sequential numbering?
- **Index/MOC files**: Are there `index.md`, `00-*.md`, or MOC files at each level?

### 1.3 Count per module

```python
from collections import Counter
dirs = Counter()
for f in all_mds:
    rel = f.replace(root, "").lstrip("/")
    parts = rel.split("/")
    parent = parts[0] if len(parts) > 1 else "/"
    dirs[parent] += 1
```

This reveals which modules are overweighted or under-invested.

---

## Phase 2: Quantitative Analysis

### 2.1 File size distribution

```python
sizes = []
for f in all_mds:
    sz = os.path.getsize(f)
    sizes.append(sz)
```

Metrics to compute:
| Metric | Meaning | Warning signal |
|--------|---------|----------------|
| Total size & file count | Scale of knowledge base | — |
| Avg / median file size | Density per note | < 2KB median → too many stubs |
| Files < 1KB | Stub/placeholder ratio | > 15% → cleanup needed |
| Files > 50KB | Monolithic note ratio | > 5% → may need splitting |

### 2.2 Frontmatter health

```python
no_frontmatter = 0
frontmatter_count = 0
no_tags = 0
no_aliases = 0
for f in all_mds:
    with open(f, 'r') as fh:
        content = fh.read()
    if content.startswith('---'):
        frontmatter_count += 1
        parts = content.split('---', 2)
        fm = parts[1]
        if 'tags:' not in fm:
            no_tags += 1
        if 'aliases:' not in fm:
            no_aliases += 1
    else:
        no_frontmatter += 1
```

Key ratios:
- **Frontmatter coverage**: `frontmatter_count / len(all_mds)` — target > 90%
- **Tag coverage**: `(frontmatter_count - no_tags) / frontmatter_count` — target > 85%
- **Alias coverage**: `(frontmatter_count - no_aliases) / frontmatter_count` — target > 70%

### 2.3 Link density

```python
import re
total_links = 0
for f in all_mds:
    with open(f, 'r') as fh:
        content = fh.read()
    total_links += len(re.findall(r'\[\[([^\]]+)\]\]', content))

link_density = total_links / len(all_mds)
```

- **Low** (< 3 per file): vault is mostly isolated islands
- **Medium** (3-8 per file): decent connectivity
- **High** (> 8 per file): rich cross-linking (target)

### 2.4 Tag consistency check

Check for quoted vs unquoted YAML tags — Obsidian treats `"六韬智脑"` and `六韬智脑` as different tags.

```python
tag_counts = {}
for f in all_mds:
    with open(f, 'r') as fh:
        content = fh.read()
    if content.startswith('---'):
        # ... extract YAML tags and count
```

If a tag appears in both quoted and unquoted forms, flag for cleanup.

### 2.5 Pipeline health (raw/processed ratio)

For vaults with a "feed pipeline" pattern (`01-信息流/` or similar):

```python
# Count raw vs processed files in the pipeline directory
raw_count = search_files(pattern="status: raw", target="content", path=info_flow_path)
processed_count = search_files(pattern="status: processed", target="content", path=info_flow_path)
digestion_rate = processed_count / (raw_count + processed_count)
```

- **Digestion rate < 50%**: pipeline is backing up — P0 issue
- **Digestion rate 50-80%**: needs attention
- **Digestion rate > 80%**: healthy

---

## Phase 3: Qualitative Assessment

### 3.1 Architecture evaluation

Check the meta-model:
- Is there a clear organizing metaphor? (tree / building / river / garden / etc.)
- Is every module's purpose documented? (total lack of index files is a red flag)
- Are cross-module relationships documented? (explicit connection tables → good sign)

Read the top-level index/MOC files. Note:
- Whether the hook in the architecture is followed consistently at lower levels
- Whether the modular boundaries are clear or leaky
- Whether there are orphan entries that don't follow the naming convention

### 3.2 Content quality sampling

Read 3-5 representative content files across different modules. Check:
- **Depth**: Is it a quick summary or a structured analysis?
- **Linking**: Does it reference other notes in the vault?
- **Actionability**: Does it connect to decision-making or practice?
- **Freshness**: When was it last updated?

### 3.3 Cross-module connectivity

Key diagnostic: **the concept/wiki layer**. A vault that depends on a shared concept layer (e.g. `wiki/` or `concepts/`) should have enough concept pages to cover the main cross-domain ideas. If concepts are < 5% of total files, the neural network of the vault is too thin.

### 3.4 Standards compliance

If SCHEMA.md or similar standards exist:
- Check freshness (last updated date)
- Check whether notes actually follow the stated conventions
- Check whether the SCHEMA itself needs updating (new file types, new naming needs that evolved organically)

---

## Phase 4: Bottleneck Diagnosis

Organize findings into a bottleneck framework. The common categories are:

| Code | Category | Symptoms |
|------|----------|---------|
| 🔴 P0 | **Pipeline blockage** | Raw materials piling up, low digestion rate, inconsistency between index and actual files |
| 🔴 P1 | **Thin connective tissue** | Low wiki/concept count, weak cross-module links, tag noise |
| 🟡 P2 | **Weak practice loop** | Few case studies, no synthesis notes, no feedback from practice back into knowledge |
| 🟡 P2 | **Missing self-checks** | No linting, no health metrics, no automated reports |
| 🟢 P3 | **Under-invested modules** | Some branches of the knowledge tree have 1/5 the files of others |
| 🔵 P4 | **Meta-evolution** | The organizing system itself isn't being updated as the vault grows |

---

## Phase 5: Evolution Planning

Present findings in a tiered priority format:

```
P0 🔴 [Immediate: 1-2 days] — Fixes that unblock the whole system
  1. Process pipeline backlog (batch raw→processed)
  2. Fix tag conflicts (quoted vs unquoted)
  3. Sync indices with actual files

P1 🟡 [Short-term: 3-5 days] — Strengthen the network
  1. Expand concept/wiki layer to X+ entries
  2. Introduce synthesis/fusion note type
  3. Create missing MOC or index files

P2 🟢 [Ongoing] — Close the practice loop
  1. Standardize case study template
  2. Set up automated linting (cron job)
  3. Establish health metrics dashboard

P3 🔵 [Long-term] — Meta-evolution
  1. Upgrade organizing schema for new scale
  2. Introduce retrieval analytics
  3. Output archive (query/discussion products)
```

Each item should include:
- Concrete action
- Estimated effort
- Who should do it (if working in a team context)
- How to verify it's done

---

## Phase 6: Remediation — Fixing the Bottlenecks

> Supporting files in this skill: `references/tag-cleanup-script.md` (tag cleanup), `references/wiki-concept-batch-creation.md` (concept expansion), `templates/fusion-note.md` (synthesis notes), `references/2026-05-30-六韬知识库审计.md` (full audit example).

The audit identifies bottlenecks. This phase provides the actual fix techniques.

### 6.1 Fix Pipeline Blockage (P0)

When the info-flow/feed directory has a low digestion rate:

**Step 1 — Cross-reference**: For each raw file, check if a corresponding knowledge entry exists via grep:
```python
import subprocess
for fname in os.listdir(info_dir):
    # Check if the base name is referenced in any .md file outside info_dir
    result = subprocess.run(["grep", "-rl", base_name, vault_root, "--include=*.md"],
                            capture_output=True, text=True)
```

**Step 2 — Triage**:
| Category | Criteria | Action |
|----------|----------|--------|
| ✅ Already processed (has corresponding entry) | grep finds refs | Add `source_note` to knowledge entry's frontmatter + set info file status = processed |
| 📝 Worth distilling | >1KB, unique content not yet captured | Quick extraction → inject to appropriate module |
| 🗑️ Skip | Stub/placeholder, template, template instance | Mark `status: archived` or leave as is |
| 📄 Tool/doc (not knowledge) | System prompts, tool definitions | Mark `status: processed` w/ tool tag, no entry needed |

**Step 3 — Add source_note backlinks** to knowledge entries that don't have them:
```yaml
# In the knowledge entry's frontmatter:
source_note: "[[01-信息流/XXX]]"
```

**Step 4 — Sync the info-flow index.md** with actual files.

### 6.2 Fix Tag Noise (P0)

When YAML tags use inconsistent formats (inline `tags: [a, b]` vs list `tags:\n  - a`):

**Detection**:
```bash
grep -rn "^tags: \[" vault_root --include="*.md"
```

**Fix — Inline-to-list conversion**:
```python
import re
def convert_inline_tags(content):
    def _convert(match):
        raw = re.search(r'tags:\s*\[(.*?)\]', match.group(0))
        if not raw:
            return match.group(0)
        tags = [t.strip().strip('"').strip("'").strip() for t in raw.group(1).split(',') if t.strip()]
        if not tags:
            return "tags: []"
        return "tags:" + "".join(f"\n  - {t}" for t in tags)
    return re.sub(r'^tags:\s*\[.*?\]', _convert, content, count=1, flags=re.MULTILINE)
```

Apply to all files found. Verify with same grep after. This eliminates the "same tag, different format" problem in Obsidian's graph view.

### 6.3 Expand Wiki / Concept Layer (P1)

When the concept layer is too thin (< 10% of total files):

**Step 1 — Identify candidates**: Scan the knowledge base for concepts that appear in 3+ modules. From MOC/index files, extract top-level themes. Look for nouns that bridge domains (e.g. "灰度" appears in 智脑(management), 易哲(philosophy), 史鉴(history)).

**Step 2 — Batch-create concept pages** with consistent format:

```yaml
---
title: Concept Name (Chinese)
tags:
  - wiki
  - cross-module
  - concept
aliases:
  - alternative names in English/Chinese
created: YYYY-MM-DD
type: concept
---

# Concept Name

> One-line definition that captures the essence.

## Cross-Module Mapping

| Module | Linked Note | Role of This Concept in That Module |
|--------|-------------|-------------------------------------|
| 六韬智脑 | [[link]] | — |
| 六韬史鉴 | [[link]] | — |

---

*Concept node — links knowledge modules together*
```

**Step 3 — Update the wiki/index.md** with categorization tables (group concepts by domain: philosophical, cognitive, strategic, business).

**Target**: 30+ concept pages for a 200+ file vault. Each concept should link to 2-4 module-level notes.

### 6.4 Launch Fusion / Synthesis Note Pattern (P1)

When 决断之桥 or equivalent synthesis layer is weak:

**Create a template** in the appropriate directory:
```markdown
---
title: 🌉 Fusion Note — [Topic]
tags:
  - [module]
  - fusion-note
type: fusion
---

## Trigger

[What real-world problem or discovery prompted this cross-module conversation.]

## Participating Modules

| Module | Perspective | Notes Used |
|--------|-------------|------------|
| 🧠 智脑 | | |
| 💭 易哲 | | |
| 📖 史鉴 | | |

## Cross-Examination

[Modules challenge each other's assumptions and findings.]

## Synthesis Conclusion

[What new insight emerged that no single module could produce alone.]

## Landing

- [ ] Action taken → [[case study]]
- [ ] Changed cognition → [[wiki/concept]]

## Backflow

- [[entry 1]] — corrected/clarified
```

Publish the first fusion note using an existing cross-module relationship (e.g. one already documented in a build log or MOC table). This creates a demonstration effect for future fusion notes.

### 6.5 Standardize Case Study / Practice Loop (P2)

When the practice-validation layer is thin:

**Define a case study frontmatter**:
```yaml
type: case-study
status: drafted | validated | iterated
hypothesis: "My judgment before acting was..."
reflection:
  - What was right
  - What was wrong
  - What this corrects in the knowledge base
```

Add a case study template to the module directory.

### 6.6 Automate Health Checks (P2)

Create a cron job (delegate to executor role) that runs weekly:
1. Scan for broken `[[links]]` pointing to nonexistent files
2. Scan for orphan pages (0 inbound links, excluding index/MOC files)
3. Scan for raw material >7 days stale
4. Report to user's messaging platform

## Pitfalls (Remediation-Specific)

- **Info flow triage is not 1-to-1**: Some info files bypass the pipeline entirely (user sent directly to knowledge entry). Always cross-reference via grep before counting "unprocessed."
- **Wiki concepts need curated linking**: After creating concept pages, update existing high-value notes to link to them. Otherwise concept pages are isolated nodes.
- **Fusion notes should be rare, not routine**: Not every cross-reference needs a fusion note. Reserve for insights that genuinely change cognition. Target ratio: 1 fusion note per ~20 knowledge entries.
- **Don't over-engineer tags**: After the initial cleanup, let tags emerge naturally. Obsidian's graph handles ~50 distinct tags well.

## Phase 7: Codification

After the audit:
1. Save audit findings as a reference file under this skill
2. Save batch scripts as references/ files for reproducibility
3. If new patterns emerged, create or update templates in `templates/` 
4. If the user expressed preferences about format or depth, embed them here

## General Pitfalls

- **Don't trust the index alone**: Always verify actual file count vs indexed file count. Indices go stale.

- **Don't trust the index alone**: Always verify actual file count vs indexed file count. Indices go stale.
- **Don't assume raw materials are waste**: Some raw materials are bypassed by direct-to-knowledge-entry workflows. Check for source_note links before counting as unprocessed.
- **Don't diagnose without sampling**: Quantitative metrics without content sampling miss context (e.g., a stub might be intentionally templated vs truly abandoned).
- **Don't propose P0 cleanup without checking labels**: Some "raw" notes in 01-信息流 may have been intentionally left as reference material, never meant for processing.
- **Don't prescribe a fix without understanding the user's rhythm**: A user who batch-processes weekly has different needs than one who processes daily.
