---
name: feishu
display_name: Feishu API — Document & API Operations
description: Create, read, and manage Feishu documents programmatically via the Feishu Open API (docx, auth, block operations).
agent_created: true
version: 1.0.0
tags: [feishu, lark, docx, api, document-creation, block-api]
trigger: 用户要求"做成飞书文档"、"创建飞书文档"、"更新飞书文档"等
---

# Feishu API — Document & API Operations

> 通过飞书 Open API 创建和操作飞书文档。当前版本支持 docx API（文档创建+块操作）。

---

## 一、认证

### 1.1 获取 tenant_access_token

只有 App ID + App Secret 方式可用（凭据为 Base 专用应用）：

```python
import requests
r = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
    json={"app_id": "cli_aa869b8d6b3c5cc3", "app_secret": "qSk4tz1A15aWo5K4eFw2lbhibgMAVaHN"}, timeout=10)
token = r.json()['tenant_access_token']
```

**注意：** `cli_aa995101f6f81cc3`（网关应用的 app_id）的 secret 已过期无效。始终使用 Base 应用的凭据。

### 1.2 Curl 版本（用于终端）

```bash
TOKEN=$(curl -s -m 10 -X POST \
  'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal' \
  -H 'Content-Type: application/json' \
  -d '{"app_id":"cli_aa869b8d6b3c5cc3","app_secret":"qSk4tz1A15aWo5K4eFw2lbhibgMAVaHN"}' | \
  python3 -c "import sys,json; print(json.load(sys.stdin)['tenant_access_token'])")
```

---

## 二、文档创建（docx API）

### 2.1 创建空文档

```python
headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
r = requests.post("https://open.feishu.cn/open-apis/docx/v1/documents",
    headers=headers, json={"title": title}, timeout=10)
doc_id = r.json()['data']['document']['document_id']
```

创建后文档链接格式：`https://bytedance.feishu.cn/docx/{doc_id}`

### 2.2 添加内容块

从 markdown 解析后，通过批量添加子块写入内容：

```python
def add_batch(token, doc_id, parent_id, blocks):
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    r = requests.post(
        f"https://open.feishu.cn/open-apis/docx/v1/documents/{doc_id}/blocks/{parent_id}/children",
        headers=headers, json={"children": blocks}, timeout=60
    )
    return r.json().get('code') == 0
```

### 2.3 Feishu Block 类型映射表

| 块类型 | block_type | 字段名 | 说明 |
|:------|:----------:|:------|:----|
| Text 段落 | 2 | `text` | 最常用的块 |
| 标题1 | 3 | `heading1` | |
| 标题2 | 4 | `heading2` | |
| 标题3 | 5 | `heading3` | |
| 标题4 | 6 | `heading4` | |
| 无序列表 | 12 | `bullet` | |
| 有序列表 | 13 | `ordered` | |
| 代码块 | 14 | `code` | **不加 `style` 字段** |
| 分隔线 | 17 | ❌ | **API不支持创建**，跳过 |

### 2.4 代码块特殊处理

代码块的 `style` 字段**不要添加**——无论填什么值（"PlainText"/"Python"/""）都会报错 `9499 Invalid parameter type in json: style`。

```python
# ✅ 正确
{"block_type": 14, "code": {"elements": [{"text_run": {"content": code_text}}]}}

# ❌ 错误 — 不要加 style
{"block_type": 14, "code": {"elements": [...], "style": "Python"}}
```

### 2.5 分隔线处理

API 不支持创建 `block_type: 17`（divider）的块。遇到 markdown 中的 `---` / `***` / `___` 直接跳过不解析。

### 2.6 表格处理

API 不支持直接创建表格块。将 markdown 表格渲染为无样式代码块：

```python
{"block_type": 14, "code": {"elements": [{"text_run": {"content": "\n".join(table_lines)}}]}}
```

### 2.7 文本元素样式

| 样式 | 写法 |
|:----|:-----|
| 加粗 | `{"text_run": {"content": text, "text_element_style": {"bold": true}}}` |
| 行内代码 | `{"text_run": {"content": text, "text_element_style": {"inline_code": true}}}` |
| 链接 | `{"text_run": {"content": text, "text_element_style": {"link": {"url": url}}}}` |
| 普通 | `{"text_run": {"content": text}}` |

### 2.8 批量大小

每次 POST 最多添加 **30 个块**。超过 30 要分批发送。如果批次失败，降级为逐块添加（单块成功率较高）。

---

## 三、完整工作流

从 markdown 文件创建飞书文档的推荐流程：

```
① 获取 auth token
② 创建文档（获得 doc_id）
③ 解析 markdown → Feishu block 数组
   - 跳过分隔线（---）
   - 代码块不加 style
   - 表格转为无样式代码块
   - 粗体标记 **xxx** 转为 text_element_style.bold=true
④ 每30个块一批，POST 到 /children 端点
⑤ 批次失败时降级为逐个添加
⑥ 返回文档链接
```

参考脚本：`scripts/create-feishu-doc.py`

---

## 四、已知坑 & 排查

| 问题 | 原因 | 解决 |
|:----|:-----|:-----|
| `tenant_access_token` KeyError | App Secret 过期/不匹配 | 检查 app_id 和 app_secret 是否对应 |
| `9499 Invalid parameter type in json: style` | 代码块加了 `style` 字段 | 完全删除 style |
| `1770001 invalid param` | block_type 17 (divider) API 不支持 | 跳过分隔线 |
| `1770029 block not support to create` | 根 block 不允许创建子块 | 确认使用正确的 block_id（= doc_id 的 page block） |
| 空响应（HTTP 200 但无 body） | 罕见 API 错误 | 重试或跳过该块 |
| 跨模块导入 | `/open-apis/docx/` 路径是飞书国际版 | 国内版用 `open.feishu.cn` |
