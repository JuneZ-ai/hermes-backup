---
name: pdf-processing
version: 1.0
author: Yanqing
description: A class-level skill for handling scanned PDFs in WSL environment, covering OCR extraction, model selection, and error recovery patterns.
---

# pdf-processing

## Overview
A class-level skill for handling scanned PDFs in WSL environment, covering OCR extraction, model selection, and error recovery patterns. Designed for reliability when dealing with non-text-based PDFs.

## Triggers
- User uploads a PDF file
- Command to extract text from PDF fails with empty output
- Model request involves document processing
- System reports "No space left on device" during installation

## Workflow
## Workflow
1. **Validate PDF type**: Use `pymupdf` to check if text layer exists via `page.get_text("text")`
2. **Choose extraction method**:
   - If substantial text exists → use `fitz.get_text()` and write MD directly
   - If text is empty/thin (<500 chars for a multi-page book) → treat as scanned PDF, proceed to OCR
3. **OCR path for scanned PDFs in this WSL environment**:
   - **Preferred**: Vision-based OCR via `vision_analyze` on page images rendered with `pymupdf` (`page.get_pixmap(dpi=200)`)
   - This avoids dependency on system OCR binaries (tesseract/easyocr/paddleocr) which are typically NOT installed in WSL
   - **Cost-aware strategy**: Do NOT run every page through vision. Sample strategically:
     - Always extract: cover (page 1), copyright/imprint (page 2), TOC (page 3+ until found), first content page of each chapter
     - Build a structural outline from sampled pages, then only OCR the remaining pages if the full text is actually needed
   - **If full text is required**: Batch pages into groups of 5-10 and parallelize via `delegate_task` or background vision calls
4. **Handle environment constraints**:
   - This WSL has no sudo access for installing OCR binaries
   - `pip install` fails due to externally-managed-environment (PEP 668)
   - Do not retry failed pip installs; pivot to vision-based approach immediately
5. **Output format**: Write Markdown with page markers (`--- Page N ---`), frontmatter with source PDF path, and preserved Q&A/heading structure where possible

## Pitfalls
- ❌ Do not retry failed pip installations without checking disk space
- ❌ Avoid using `--break-system-packages` unless necessary
- ❌ Never assume `/tmp` has sufficient space; always verify
- ❌ Do not rely on model-free OCR if user expects high accuracy
- ❌ WSL environments often lack sudo and have PEP 668 pip restrictions — do not waste turns trying to install tesseract/easyocr/paddleocr; pivot to vision-based OCR on page images immediately
- ❌ Do not run vision_analyze on every page of a large scanned PDF (e.g. 400+ pages) — costs explode. Sample strategically: cover, copyright, TOC, chapter starts. Only OCR all pages if full text is explicitly required.
- ❌ `page.get_text()` returning a few chars on a 400-page PDF is a strong signal the PDF is scanned/image-based, not a usable text layer — do not output the near-empty result as the final MD.
- ❌ 对扫描件PDF提取了"近似空结果"后不要立即放弃：先用pymupdf转图片（`page.get_pixmap(dpi=200)`），然后用vision_analyze逐页或抽样识别。优先抽样前15-20页建目录框架，全量OCR仅在用户明确要求时进行。
- ❌ 对400页+的扫描件PDF，不要无差别全量vision——成本会爆炸。策略：1）抽样前15-20页建目录框架；2）仅对用户指定章节或高价值页面全量OCR；3）其余页面保留图片待命，在搭建日志中标注"待OCR"状态。

## References
- [references/ocr-workflow.md](references/ocr-workflow.md)
- [references/pip-install-failure.md](references/pip-install-failure.md)

## Templates
- [templates/pdf-extract.sh](templates/pdf-extract.sh)