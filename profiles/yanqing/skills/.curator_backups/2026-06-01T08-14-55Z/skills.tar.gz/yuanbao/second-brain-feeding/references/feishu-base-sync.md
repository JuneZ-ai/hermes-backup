# 飞书 Base 同步配置参考

## 连接信息

- **Base Token**: `NzuPbMtMFa0wUusVQKwc69lenib`
- **Table ID**: `tbllV9WgN64Zwput`
- **Feishu App ID**: `cli_aa869b8d6b3c5cc3`
- **Feishu App Secret**: 存于 `~/.hermes/.env` → `FEISHU_APP_SECRET`

## 权限要求

飞书应用需要开通权限：
- `bitable:app` — 多维表格读写

## API 端点

| 操作 | 端点 |
|------|------|
| 获取 token | `POST /open-apis/auth/v3/tenant_access_token/internal` |
| 列出字段 | `GET /open-apis/bitable/v1/apps/{base_token}/tables/{table_id}/fields` |
| 列出记录 | `GET /open-apis/bitable/v1/apps/{base_token}/tables/{table_id}/records` |
| 新增记录 | `POST /open-apis/bitable/v1/apps/{base_token}/tables/{table_id}/records` |

## 同步脚本

路径：`~/.hermes/profiles/yanqing/scripts/sync-log-to-feishu.py`

逻辑：
1. 获取 tenant_access_token
2. 读取 OB vault 搭建日志 → 解析日期区块 → 提取表格任务行
3. 读取飞书 Base 已有记录的「操作内容」作为去重依据
4. 新增不重复的记录
5. 按关键词自动推断「领域」字段

## 领域映射规则

| 关键词 | 映射领域 |
|--------|---------|
| 飞书、权限、API、bitable、token | 飞书权限开通 |
| 工具、配置、OCR、Tesseract、脚本、定时 | 工具配置 |
| 架构、设计、决策、规划 | 架构决策 |
| 其他（默认） | 知识库基建 |

## 定时任务

- 频率：每天 21:00（北京时间）
- 命令：`hermes cron list` 查看状态
- 手动触发：`cd ~/.hermes/profiles/yanqing && python3 scripts/sync-log-to-feishu.py`
- 去重字段：`操作内容`（精确匹配）
