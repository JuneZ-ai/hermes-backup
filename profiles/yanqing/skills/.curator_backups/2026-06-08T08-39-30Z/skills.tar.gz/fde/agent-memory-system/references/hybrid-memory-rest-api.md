# Hybrid-Memory REST API

> **REST 封装** — 将 hybrid-memory MCP 暴露为 HTTP 服务，供下游产品（包打听等）通过 JSON API 调用。

## 服务基本信息

| 项 | 值 |
|:---|:---|
| 端口 | 8421 |
| 启动方式 | `python3 rest_server.py --port 8421` |
| 环境变量 | `HYBRID_MEMORY_DB` — BM25 索引 SQLite 文件路径（默认 `~/.hermes/hybrid-memory/bm25_index.db`） |
| 启动脚本 | `~/.hermes/profiles/yanqing/scripts/hybrid-memory/start-rest-server.sh` |
| 代码位置 | `~/.hermes/profiles/yanqing/scripts/hybrid-memory/rest_server.py` |

## 端点

### POST /index/batch — 批量入库

企业经验写入 BM25 索引。entry_id 重复会覆盖。

```json
{
  "entries": [
    {"entry_id": "exp-001", "session_id": "acme-corp",
     "content": "去年客户投诉处理流程：先确认问题等级→48小时响应→升级机制→复盘归档",
     "source": "经验采录"},
    {"entry_id": "exp-002", "session_id": "acme-corp",
     "content": "王总对供应商选择的核心标准：交付准时＞价格＞服务响应",
     "source": "决策记录"}
  ]
}
```

### POST /search — 混合检索（BM25 + 向量 + RRF）

```json
{
  "query": "客户投诉怎么处理",
  "session_id": "acme-corp",
  "limit": 3
}
```

返回排序后的结果列表，每项包含 `entry_id`、`content`、`source`、`rrf_score`。

### POST /bm25-search — 纯 BM25 关键词检索

参数同 `/search`，仅返回 BM25 匹配结果。

### GET /index/stats — 索引统计

```json
{
  "total_entries": 4,
  "database_size": 4096,
  "database_size_hr": "4.0KB"
}
```

### GET /health — 健康检查

```json
{
  "status": "ok",
  "total_entries": 4
}
```

## 集成方式

**服务启动**：
```bash
export HYBRID_MEMORY_DB=~/.hermes/hybrid-memory/bm25_index.db
chmod +x start-rest-server.sh
./start-rest-server.sh
```

**客户端调用**（从任意脚本或 Agent 工具中）：
```python
import requests
BASE = "http://localhost:8421"
r = requests.post(f"{BASE}/search", json={"query": "供应商", "session_id": "acme", "limit": 2})
results = r.json()["results"]
```

**架构定位**：REST 服务是后端组件，被六韬 bot 团队（燕青/扫地僧/黄老邪/Hermes-Junis）调用来回答用户的企业经验查询。bot 团队即用户入口。
