---
name: agent-memory-system
description: "Agent 记忆管理系统 — 整合上下文压缩、混合检索、用户画像、渐进注入、断点恢复为统一体系。源自腾讯 TencentDB-Agent-Memory 吸收落地（Phase 1-3）。"
version: 1.0.0
author: 燕青
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [memory, context, compression, profile, retrieval, checkpoint, fde]
---

# Agent Memory System

> **让 Agent 记住该记住的，人能专注于判断和创造。**
> 六韬 FDE 记忆体系 = 符号化短时 + 分层长时 + 混合检索 + 渐进注入 + 断点恢复。
> 哲学根基：人为知识负责（主动驾驭），而非全自动管道（被动捕获）。

## 架构概览

```
                         ┌─────────────────────────────┐
                         │  渐进式上下文注入协议          │
                         │  (L3画像→L2场景→L1事实→L0日志)│
                         └──────────┬──────────────────┘
                                    │ 按需加载
     ┌──────────────────────────────┼──────────────────────────────┐
     │                              │                              │
     ▼                              ▼                              ▼
┌────────────┐           ┌──────────────────┐           ┌──────────────────┐
│ 符号化压缩  │           │ 混合检索 MCP      │           │ 任务断点恢复      │
│ (STM)      │◄─────────►│ (BM25+向量+RRF)   │◄─────────►│ (checkpoint)     │
└──────┬─────┘           └────────┬─────────┘           └────────┬─────────┘
       │                          │                              │
       ▼                          ▼                              ▼
   refs.md + canvas.md     hybrid-memory MCP             state.json + summary.md
   (卸载+回溯)              (5 tools)                     (保存+恢复)
```

## 五组件详解

### 1. 符号化上下文压缩（Symbolic STM）

**问题**：长任务中工具日志膨胀，几十万 Token 堆在上下文。

**方案**：自动将工具输出摘要为 Mermaid 状态图，完整文本卸载到 refs 文件。

```
Verbose Logs → ① 卸载到 refs.md
             → ② 提取关键状态 → Mermaid 画布（数百Token）
             → ③ node_id 回溯：grep 'node_id:xxx' refs.md
```

**触发条件**：上下文 >50% / 单步输出 >5K tokens / 连续3+工具调用

**脚本**：`~/.hermes/profiles/yanqing/scripts/mermaid-offload/mermaid_offload.py`

### 2. BM25 + 向量混合检索（Hybrid Search MCP）

**问题**：纯向量检索中文关键词匹配弱。

**方案**：jieba 分词 → BM25 FTS5 + 向量语义 → RRF(k=60) 融合排序

```
MCP: hybrid-memory (已注册，5 tools)
├── memory_hybrid_search    混合搜索
├── memory_bm25_search      BM25 关键词
├── memory_vector_search    向量语义
├── memory_index_add        添加索引
└── memory_index_stats      索引统计
```

**验证**：42/42 测试通过。

**配置**：`hermes mcp test hybrid-memory`

### 3. 半自动用户画像（Auto-Profile）

**问题**：Agent 每次对话都像第一次见到用户。

**方案**：Agent 生成草稿 → 人审核确认 → 注入 memory（非全自动，保持主动驾驭）

```
/profile generate   → Agent 读对话历史 → 生成结构化画像草稿
/profile review     → 用户查看 Markdown 完整草稿
/profile confirm    → 确认后注入 ~/.hermes/memories/USER.md（下次对话自动生效）
```

**脚本**：`~/.hermes/profiles/yanqing/scripts/auto-profile/`（生成器+注入器+审核）

**画像模板**：6 个维度（偏好/决策模式/习惯/避坑经验/知识盲区/自动化偏好），每条标注置信度+来源会话

### 4. 渐进式上下文注入协议（Progressive Injection）

**问题**：Agent 每次开工把整条历史拉进来，而非只加载必需的。

**方案**：由表及里逐层注入

| 层 | 内容 | 注入策略 |
|:---|:-----|:---------|
| L3 | 用户画像 + 当前目标 | **总是加载** |
| L2 | 相关场景块 / SOP | **按需加载**（遇到特定问题时） |
| L1 | 关键事实 / 历史决策 | **按需加载**（需要事实依据时） |
| L0 | 原始日志 / 工具输出 | **不注入**（通过 node_id 回溯） |

### 5. 任务级断点恢复（Checkpoint/Resume）

**问题**：长任务（30+轮）中断后，Agent 不记得做到哪了。

**方案**：在关键里程碑保存任务状态，中断后 load 恢复。

```python
# 里程碑保存
save_checkpoint(task_id, goal, completed_steps, partial_outputs, next_plan)

# 中断后恢复
state = load_checkpoint(task_id)
# state = {goal, completed_steps, partial_outputs, next_plan}

# 任务完成后清理
force_delete_checkpoint(task_id)
```

**脚本**：`~/.hermes/profiles/yanqing/scripts/task-checkpoint/checkpoint.py`

**原理**：纯 JSON + Markdown，人可读可改。Hermes /rollback 和 /snapshot 是配置级快照，这个是任务级。

## 各组件的关系

```
长任务开始
    │
    ├── Mermaid 压缩 ← Token 压力大时自动卸载工具日志
    │
    ├── 混合检索 MCP ← 需要查找历史记忆时调用
    │
    ├── 渐进注入 ← 每次构建上下文时按 L3→L2→L1 加载
    │
    ├── 用户画像 ← 跨会话偏好，每 session 启动时自动加载
    │
    └── 断点恢复 ← 关键里程碑保存，中断后恢复
```

## 设计原则

1. **人为知识负责**：所有写入 memory 的内容必须经人确认（Profile）
2. **白盒可调试**：每一层都是可读 Markdown（Canvas / Profile / Checkpoint）
3. **渐进展开**：先看概览，需要细节时逐层下钻（L3→L0）
4. **轻量不侵入**：纯 skill + Python 脚本，不修改 Hermes 核心代码
5. **博采众长**：工程技巧来自腾讯 TencentDB-Agent-Memory，设计哲学保持六韬

## 文件索引

```
scripts/                          ← Python 实现
├── mermaid-offload/              → 符号化压缩
├── hybrid-memory/                → 混合检索 MCP + REST 服务
├── auto-profile/                 → 用户画像
└── task-checkpoint/              → 断点恢复

~/.hermes/memories/USER.md              ← 生效的用户画像（由 auto-profile 注入）
~/.hermes/tmp/context-offload/          ← 卸载的完整日志（Mermaid 压缩）
~/.hermes/tmp/checkpoints/              ← 任务断点（checkpoint）

MCP: hybrid-memory（已注册）            ← 混合检索服务
REST: port 8421                         ← 包打听等下游产品通过 HTTP 调用
refs: references/hybrid-memory-rest-api.md  ← REST API 端点文档
```

## 下游产品集成

> 核心原则：**Bot 即产品入口。** 不建独立 bot/Web/API 网关。用户通过六韬 bot 团队（燕青/扫地僧/黄老邪/Hermes-Junis）直接提问，bot 调后端组件出答案。

本系统的组件已集成到**包打听（企业经验引擎）**：

| 组件 | 产品用途 | 集成方式 |
|:-----|:---------|:---------|
| hybrid-memory | 检索层 | REST 封装(8421)，HTTP 调用 |
| Mermaid 压缩 | 深度分析报告 | Agent 触发 |
| 渐进注入 | 回答生成策略 | 行为指导 |
| 用户画像 | 企业客户画像 | 半自动 + 人确认 |

详见 `Delivery/企业交付/Toolkits/包打听-技术架构-v0.1.md`。
